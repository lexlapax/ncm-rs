use candle_core::cuda_backend::cudarc::cublaslt::{
    CudaBlasLT, Matmul, MatmulConfig, MatmulShared, Workspace, sys,
};
use candle_core::cuda_backend::cudarc::driver::CudaStream;
use candle_core::{Device, Tensor};
use std::sync::Arc;
struct Strict(CudaBlasLT);
impl MatmulShared for Strict {
    fn handle(&self) -> &sys::cublasLtHandle_t {
        self.0.handle()
    }
    fn workspace(&self) -> &Workspace {
        self.0.workspace()
    }
    fn stream(&self) -> &Arc<CudaStream> {
        self.0.stream()
    }
}
impl Matmul<f32> for Strict {
    fn matrix_type() -> sys::cudaDataType {
        sys::cudaDataType_t::CUDA_R_32F
    }
    fn compute_type() -> sys::cublasComputeType_t {
        sys::cublasComputeType_t::CUBLAS_COMPUTE_32F
    }
}
use std::{error::Error, time::Instant};
#[allow(unsafe_code)]
fn main() -> Result<(), Box<dyn Error>> {
    let dev = Device::new_cuda(0)?;
    let cuda = dev.as_cuda_device()?;
    let stream = cuda.cuda_stream();
    let lt = Strict(CudaBlasLT::new(stream.clone())?);
    let (m, n, k) = (768usize, 356usize, 256usize);
    let x: Vec<f32> = (0..n * k)
        .map(|i| ((i * 31 % 101) as f32 - 50.) / 100.)
        .collect();
    let w: Vec<f32> = (0..m * k)
        .map(|i| ((i * 17 % 103) as f32 - 51.) / 100.)
        .collect();
    let b: Vec<f32> = (0..m).map(|i| ((i % 31) as f32 - 15.) / 10.).collect();
    let tx = Tensor::from_slice(&x, (n, k), &dev)?;
    let tw = Tensor::from_slice(&w, (m, k), &dev)?;
    let tb = Tensor::from_slice(&b, (m,), &dev)?;
    let dx = stream.clone_htod(&x)?;
    let dw = stream.clone_htod(&w)?;
    let db = stream.clone_htod(&b)?;
    let cfg = MatmulConfig {
        transa: true,
        transb: false,
        transc: false,
        m: m as u64,
        n: n as u64,
        k: k as u64,
        alpha: 1.,
        lda: k as i64,
        ldb: k as i64,
        beta: 0.,
        ldc: m as i64,
        stride_a: None,
        stride_b: None,
        stride_c: None,
        stride_bias: None,
        batch_size: None,
    };
    let mut old = Vec::new();
    let mut new = Vec::new();
    let mut max_error = 0f32;
    for i in 0..36 {
        dev.synchronize()?;
        let start = Instant::now();
        let reference = tx.matmul(&tw.t()?)?.broadcast_add(&tb)?;
        dev.synchronize()?;
        let t = start.elapsed().as_secs_f64() * 1000.;
        if i >= 6 {
            old.push(t)
        }
        dev.synchronize()?;
        let start = Instant::now();
        let mut output = unsafe { stream.alloc::<f32>(m * n)? };
        unsafe { lt.matmul(cfg, &dw, &dx, &mut output, Some(&db), None)? };
        dev.synchronize()?;
        let t = start.elapsed().as_secs_f64() * 1000.;
        if i >= 6 {
            new.push(t)
        }
        if i == 0 {
            let a = reference.flatten_all()?.to_vec1::<f32>()?;
            let z = stream.clone_dtoh(&output)?;
            for (&u, &v) in a.iter().zip(&z) {
                max_error = max_error.max((u - v).abs());
            }
        }
    }
    old.sort_by(f64::total_cmp);
    new.sort_by(f64::total_cmp);
    println!(
        "{{\"shape\":[{n},{k},{m}],\"baseline_median_ms\":{},\"fused_median_ms\":{},\"max_abs_error\":{max_error},\"output_buffer_allocation_timed\":true,\"diagnostic_only\":true}}",
        (old[14] + old[15]) / 2.,
        (new[14] + new[15]) / 2.
    );
    Ok(())
}
