import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/home/lexlapax/projects/lexlapax/ncm-rs'); cand=pathlib.Path('/tmp/ncm-qwen-ids-v1'); out=pathlib.Path('/tmp/ncm-qwen-ids-diagnostic-v1'); targets={'current':root/'.reference/phase2-fused-production-target-v1/release/examples/asset_bench','candidate':root/'.reference/phase2-fused-isolated-target-v2/release/examples/asset_bench'}
plan={'description':'Three fresh processes each, alternating order; pinned Qwen fixture; diagnostic only','binaries':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in targets.items()},'candidate_supplemental_source_sha256':hashlib.sha256((cand/'vendor/tokenizers-0.22.2/src/tokenizer/encoding.rs').read_bytes()).hexdigest(),'commands':[]}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for i in range(1,4):
 for n in (('current','candidate') if i%2 else ('candidate','current')):
  cwd=root if n=='current' else cand
  cmd=[str(targets[n]),str(root/'artifacts/canonical/tokenizers-qualified'),str(root/'tests/fixtures/tokenizers-v1.json'),'qwen3',str(out/f'{n}-{i}.json')]
  entry={'argv':cmd,'cwd':str(cwd),'start':time.time()};plan['commands'].append(entry);(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
  subprocess.run(cmd,cwd=cwd,env={'PATH':'/usr/bin:/bin','TOKENIZERS_PARALLELISM':'false','HF_HUB_OFFLINE':'1'},check=True)
  entry['finish']=time.time();(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
