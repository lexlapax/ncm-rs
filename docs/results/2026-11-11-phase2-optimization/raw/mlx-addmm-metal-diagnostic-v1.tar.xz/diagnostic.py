import hashlib,json,os,pathlib,subprocess,threading,time
root=pathlib.Path.home()/'projects/lexlapax/ncm-rs'; exp=root/'.reference/phase2-mlx-addmm-experiment-v1'; out=root/'reports/phase2-mlx-addmm-diagnostic-v1'; out.mkdir(exist_ok=False)
bins={'current':root/'target/release/examples/mlx_codec_bench','addmm':root/'.reference/phase2-mlx-addmm-target-v1/release/examples/mlx_codec_bench'}
meta={'plan':'Three fresh processes per candidate, alternating order; all codec scopes; diagnostic only, not acceptance.','binaries':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in bins.items()},'commands':[],'thermal_before':subprocess.check_output(['pmset','-g','therm'],text=True)}
stop=threading.Event()
def sample():
 with (out/'activity.jsonl').open('x') as f:
  while not stop.is_set():
   f.write(json.dumps({'time':time.time(),'ps':subprocess.check_output(['ps','-Ao','pcpu=,comm='],text=True)})+'\n');f.flush();stop.wait(2)
t=threading.Thread(target=sample);t.start()
try:
 for i in range(1,4):
  for n in (('current','addmm') if i%2 else ('addmm','current')):
   cmd=[str(bins[n]),str(root/'artifacts/canonical/sudoku-easy-qualified'),'tests/fixtures/codec-bench-v1.json',str(out/f'{n}-{i}.json')]; cwd=root if n=='current' else exp
   meta['commands'].append({'argv':cmd,'cwd':str(cwd)}); (out/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
   subprocess.run(cmd,cwd=cwd,env={'PATH':'/usr/bin:/bin'},check=True)
finally:
 stop.set();t.join();meta['thermal_after']=subprocess.check_output(['pmset','-g','therm'],text=True);(out/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
