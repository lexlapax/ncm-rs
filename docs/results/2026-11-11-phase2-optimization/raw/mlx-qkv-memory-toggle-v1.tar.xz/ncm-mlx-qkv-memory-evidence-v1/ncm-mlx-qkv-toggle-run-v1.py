"""Counterbalanced packed/sliced MLX memory diagnostic, not an acceptance gate."""
import hashlib,json,os,subprocess,threading
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path.home()/'projects/lexlapax/ncm-rs'; os.chdir(ROOT)
OUT=ROOT/'reports/phase2-mlx-qkv-memory-toggle-v1'; ARTIFACT=ROOT/'artifacts/canonical/sudoku-easy-qualified'
BIN={'packed':ROOT/'.reference/phase2-mlx-live-candidate-target-v1/release/examples/mlx_live_memory_probe','sliced':ROOT/'.reference/phase2-mlx-qkv-toggle-target-v1/release/examples/mlx_live_memory_probe'}
SRC={'packed':ROOT/'.reference/phase2-mlx-live-candidate-v1','sliced':ROOT/'.reference/phase2-mlx-qkv-toggle-v1'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
probe='crates/ncm-backend-mlx/examples/mlx_live_memory_probe.rs'; expected='c4372524afc86753085c9d9a89ee7bd2056756c48a771ac6dd23111ede252e4e'
if any(sha(x/probe)!=expected for x in SRC.values()):raise ValueError('probe source differs')
if {k:sha(v) for k,v in BIN.items()} != {'packed':'a9f021476418396e455805261b3dce86009eefc1be2084885721a663c97c21e3','sliced':'be680e6fa06e91f374cd168c2d66b065ffe56bad67ff840b3d615a92db81a1a3'}: raise ValueError('binary identity differs')
if {k:sha(v/'crates/ncm-model/src/blocks.rs') for k,v in SRC.items()} != {'packed':'efbc829cfb79d45d027f0013ee81fa24be52f74c5384ad254a9deb7fe30ed7b0','sliced':'65eb77fb8975bcbf39ffbd86f9892074b84cba19ea295dd1a5b140bd689b91cd'}:raise ValueError('blocks source differs')
if subprocess.check_output(['git','diff','5200924','8cd3c95','--','crates/ncm-backend-mlx','crates/ncm-model','crates/ncm-core','crates/ncm-io','crates/ncm-tokenizers','Cargo.lock'],cwd=ROOT):raise ValueError('baseline model sources differ')
if any(os.environ.get(k) for k in ('DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','MTL_CAPTURE_ENABLED')):raise ValueError('instrumented environment')
OUT.mkdir(mode=0o700)
now=lambda:datetime.now(timezone.utc).isoformat()
meta={'status':'running','started':now(),'manifest_sha256':sha(ARTIFACT/'manifest.json'),'probe_sha256':expected,'binary_sha256':{k:sha(v) for k,v in BIN.items()},'blocks_source_sha256':{k:sha(v/'crates/ncm-model/src/blocks.rs') for k,v in SRC.items()},'commands':[],'thermal_before':subprocess.check_output(['/usr/bin/pmset','-g','therm'],text=True)}
stop=threading.Event()
def save():(OUT/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
def sample():
 try:
  with (OUT/'activity.jsonl').open('x') as f:
   while not stop.is_set():
    entries=[]
    for line in subprocess.check_output(['/bin/ps','-Ao','pcpu=,comm='],text=True).splitlines():
     cpu,name=line.split(None,1);entries.append({'cpu_percent':float(cpu),'name':Path(name).name})
    f.write(json.dumps({'utc':now(),'top_cpu':sorted(entries,key=lambda x:x['cpu_percent'],reverse=True)[:12]})+'\n');f.flush();stop.wait(2)
 except Exception as e:meta['activity_error']=str(e)
save();thread=threading.Thread(target=sample);thread.start()
try:
 for repeat in range(1,4):
  for role in (('packed','sliced') if repeat%2 else ('sliced','packed')):
   report=OUT/f'{role}-{repeat}.json';argv=[str(BIN[role]),str(ARTIFACT),str(report)];entry={'role':role,'repeat':repeat,'argv':argv,'cwd':str(SRC[role]),'start':now()};meta['commands'].append(entry);save()
   with (OUT/f'{role}-{repeat}.stdout').open('xb') as stdout,(OUT/f'{role}-{repeat}.stderr').open('xb') as stderr:
    child=subprocess.run(argv,cwd=SRC[role],env={'PATH':'/usr/bin:/bin','HF_HUB_OFFLINE':'1','TOKENIZERS_PARALLELISM':'false'},stdout=stdout,stderr=stderr,timeout=120,check=False)
   entry['returncode']=child.returncode;entry['finish']=now();save()
   if child.returncode:raise RuntimeError(f'{role} {repeat} failed')
   report_obj=json.loads(report.read_bytes());
   if len(report_obj['rows'])!=12:raise ValueError('incomplete rows')
   entry['report_sha256']=sha(report);save();print(role,repeat,'complete',flush=True)
except Exception as e:meta['status']='failed';meta['error']=str(e);raise
finally:stop.set();thread.join();meta['thermal_after']=subprocess.check_output(['/usr/bin/pmset','-g','therm'],text=True);save()
if 'activity_error' in meta:meta['status']='failed';save();raise RuntimeError(meta['activity_error'])
meta['status']='complete';meta['finished']=now();save();print('six memory processes complete',flush=True)
