use std::{fs,hint::black_box,time::Instant};
fn hex(b:u8)->Option<u16>{match b {b'0'..=b'9'=>Some((b-b'0') as u16),b'a'..=b'f'=>Some((b-b'a'+10) as u16),b'A'..=b'F'=>Some((b-b'A'+10) as u16),_=>None}}
fn transform(data:&mut Vec<u8>)->usize {
 let(mut read,mut write,mut count,mut quoted)=(0,0,0,false);let len=data.len();
 while read<len {
  let b=data[read];
  if quoted && b==b'\\' && read+1<len {
   if data[read+1]==b'u' && read+5<len {
    let z=(hex(data[read+2]),hex(data[read+3]),hex(data[read+4]),hex(data[read+5]));
    if let (Some(a),Some(b),Some(c),Some(d))=z { let n=(a<<12)|(b<<8)|(c<<4)|d;
     if n>=0x80 && !(0xd800..=0xdfff).contains(&n) { let mut bytes=[0;4];let s=char::from_u32(n as u32).unwrap().encode_utf8(&mut bytes).as_bytes();for &c in s {data[write]=c;write+=1;}read+=6;count+=1;continue; }
    }
   }
   data[write]=b;data[write+1]=data[read+1];write+=2;read+=2;continue;
  }
  if b==b'"' {quoted=!quoted;}data[write]=b;write+=1;read+=1;
 }
 data.truncate(write);count
}
fn main(){let input=fs::read("artifacts/canonical/tokenizers-qualified/qwen3/tokenizer.json").unwrap();let mut times=Vec::new();let mut stats=(0,0);for i in 0..32 {let mut b=input.clone();let start=Instant::now();let n=transform(black_box(&mut b));let ms=start.elapsed().as_secs_f64()*1e3;stats=(n,b.len());if i>=2{times.push(ms)};black_box(b);}times.sort_by(|a,b|a.total_cmp(b));println!("conversions={} bytes_before={} bytes_after={} median_ms={:.4}",stats.0,input.len(),stats.1,times[15]);}
