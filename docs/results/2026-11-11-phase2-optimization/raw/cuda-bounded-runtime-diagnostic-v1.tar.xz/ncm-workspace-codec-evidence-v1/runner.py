import hashlib, json, os, pathlib, subprocess, threading
from datetime import datetime, timezone
root=pathlib.Path('/home/lexlapax/projects/lexlapax/ncm-rs')
out=pathlib.Path('/tmp/ncm-workspace-codec-evidence-v1')
identities={'target/release/examples/codec_bench':'794ba7cd4c5163331e45ffbf59cf0b49f37f6bb6b6d4565f4eae0cc9ae776254','crates/ncm-backend-cuda/src/fused_projection.rs':'92686330ae3c661d60ed291b68a069b15ca25a1103c444deb502f19708014950','crates/ncm-backend-cuda/src/fused_projection/bounded.rs':'5e5cd0fe6176dd3bd0079a73fb36e5687fa09e49f217564cffc5e56ae0740327','tests/fixtures/codec-bench-v1.json':'74a1097e5cb5daa8db10c5a785c7fc2f9220a88dddda2b3669ee8a81b3ac8eea'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if any(sha(root/p)!=v for p,v in identities.items()): raise ValueError('source or binary changed')
if any(os.environ.get(k) for k in ('LD_PRELOAD','CUDA_INJECTION64_PATH','CUDA_INJECTION32_PATH','CUDA_VISIBLE_DEVICES')):raise ValueError('instrumented or remapped environment')
out.mkdir(mode=0o700)
now=lambda:datetime.now(timezone.utc).isoformat()
meta={'status':'running','identities':identities,'runs':[],'activity_errors':[],'device':subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],text=True).strip()}
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
stop=threading.Event()
def sample():
 try:
  with (out/'activity.jsonl').open('x') as f:
   while not stop.is_set():
    gpu=subprocess.check_output(['nvidia-smi','--query-gpu=timestamp,temperature.gpu,utilization.gpu,memory.used,clocks.sm,power.draw','--format=csv,noheader,nounits'],text=True).strip()
    entries=[]
    for line in subprocess.check_output(['ps','-eo','pcpu=,comm='],text=True).splitlines():
     cpu,name=line.split(None,1); entries.append({'cpu_percent':float(cpu),'name':pathlib.Path(name).name})
    f.write(json.dumps({'utc':now(),'gpu':gpu,'top_cpu':sorted(entries,key=lambda x:x['cpu_percent'],reverse=True)[:12]})+'\n');f.flush();stop.wait(1)
 except Exception as e:meta['activity_errors'].append(str(e))
save(); thread=threading.Thread(target=sample);thread.start()
try:
 for i in (1,2,3):
  report=out/f'run-{i}.json'; cmd=[str(root/'target/release/examples/codec_bench'),str(root/'artifacts/canonical/sudoku-easy-qualified'),str(root/'tests/fixtures/codec-bench-v1.json'),str(report)]
  row={'repeat':i,'argv':cmd,'start':now()};meta['runs'].append(row);save()
  with (out/f'run-{i}.stdout').open('xb') as stdout,(out/f'run-{i}.stderr').open('xb') as stderr:
   child=subprocess.run(cmd,cwd=root,stdout=stdout,stderr=stderr,timeout=300,check=False)
  row['exit_code']=child.returncode;row['finish']=now();save()
  if child.returncode:raise RuntimeError(f'run {i} failed')
  result=json.loads(report.read_bytes());row['report_sha256']=sha(report);save();print('completed process',i,flush=True)
except Exception as e:meta['status']='failed';meta['error']=str(e);raise
finally:stop.set();thread.join();save()
if meta['activity_errors']:meta['status']='failed';save();raise RuntimeError('activity sampling failed')
meta['status']='complete';save();print('group complete',flush=True)
