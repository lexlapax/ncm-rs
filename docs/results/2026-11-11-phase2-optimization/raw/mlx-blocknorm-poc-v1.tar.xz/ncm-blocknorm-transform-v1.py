from pathlib import Path
p=Path('crates/ncm-core/src/lib.rs'); s=p.read_text(); needle='    fn rms_norm(&self, x: &Self::Tensor, weight: &Self::Tensor, eps: f64) -> Result<Self::Tensor>;'; assert s.count(needle)==1
s=s.replace(needle,'''    fn layer_norm_accelerated(&self, x: &Self::Tensor, weight: &Self::Tensor, bias: Option<&Self::Tensor>, eps: f64) -> Result<Self::Tensor> {
        self.layer_norm(x, weight, bias, eps)
    }
'''+needle);p.write_text(s)
p=Path('crates/ncm-model/src/blocks.rs');s=p.read_text();old='''        let y = self
            .backend
            .layer_norm(x, self.weight(&format!("{name}.weight"))?, bias, 1e-6)?;'''; assert s.count(old)==1
s=s.replace(old,'''        let weight = self.weight(&format!("{name}.weight"))?;
        let y = if name.starts_with("decoder.middle_block.") {
            self.backend.layer_norm_accelerated(x, weight, bias, 1e-6)?
        } else {
            self.backend.layer_norm(x, weight, bias, 1e-6)?
        };''');p.write_text(s)
p=Path('crates/ncm-backend-mlx/src/ops.rs');s=p.read_text();needle='pub fn rms_norm(x: &Array, eps: f64) -> Result<Array> {';assert s.count(needle)==1
s=s.replace(needle,'''pub fn layer_norm_accelerated(x: &Array, eps: f64) -> Result<Array> {
    let _ = epsilon(eps)?;
    Ok(mlx_rs::fast::layer_norm(x, None, None, eps as f32)?)
}
'''+needle)
old='''    Ok(x.multiply(
        x.square()?
            .mean_axis(-1, true)?
            .add(epsilon(eps)?)?
            .rsqrt()?,
    )?)''';assert s.count(old)==1
s=s.replace(old,'''    let _ = epsilon(eps)?;
    Ok(mlx_rs::fast::rms_norm(x, None, eps as f32)?)''');p.write_text(s)
p=Path('crates/ncm-backend-mlx/src/codec.rs');s=p.read_text();needle='    fn rms_norm(&self, x: &MlxTensor, weight: &MlxTensor, eps: f64) -> Result<MlxTensor> {';assert s.count(needle)==1
s=s.replace(needle,'''    fn layer_norm_accelerated(&self, x: &MlxTensor, weight: &MlxTensor, bias: Option<&MlxTensor>, eps: f64) -> Result<MlxTensor> {
        if let Some(b) = bias { check(b, Dtype::Float32)?; }
        self.array_op(&[x, weight], || {
            let y = ops::layer_norm_accelerated(&x.0, eps)?.multiply(&weight.0)?;
            Ok(match bias { Some(b) => y.add(&b.0)?, None => y })
        })
    }
'''+needle);p.write_text(s)
