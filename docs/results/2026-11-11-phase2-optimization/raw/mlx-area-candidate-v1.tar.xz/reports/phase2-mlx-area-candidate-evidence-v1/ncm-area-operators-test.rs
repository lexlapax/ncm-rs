#![cfg(feature = "mlx")]
mod support;
use mlx_rs::ops::indexing::TryIndexOp;
use mlx_rs::{Array, Device, with_device};
use ncm_backend_mlx::ops;
use support::{Fixture, Prepared, Result, check_output};

#[test]
fn linear_gather_matches_scalar_geometry_on_real_metal() -> Result<()> {
    with_device(Device::gpu(), || {
        for (batch, source, length) in [
            (1_usize, 1_usize, 89_usize),
            (1, 2, 89),
            (1, 13, 89),
            (1, 50, 89),
            (1, 89, 13),
            (4, 13, 89),
            (2, 37, 67),
            (2, 67, 37),
            (1, 5, 1),
        ] {
            let data: Vec<f32> = (0..batch * source * 64)
                .map(|i| ((i * 73 % 509) as f32 - 254.) / 37.)
                .collect();
            let x = Array::from_slice(&data, &[batch as i32, source as i32, 64]);
            let mut bins = Vec::with_capacity(length);
            for i in 0..length {
                let position = ((i as f64 + 0.5) * source as f64 / length as f64 - 0.5).max(0.);
                let lo = (position.floor() as i32).min(source as i32 - 1);
                let hi = (lo + 1).min(source as i32 - 1);
                let weight = position - f64::from(lo);
                let a = x
                    .try_index((.., lo..lo + 1, ..))?
                    .multiply(Array::from_f32((1. - weight) as f32))?;
                let b = x
                    .try_index((.., hi..hi + 1, ..))?
                    .multiply(Array::from_f32(weight as f32))?;
                bins.push(a.add(b)?);
            }
            let old = mlx_rs::ops::concatenate(&bins, 1)?;
            let new = ops::linear1d(&x, length)?;
            old.eval()?;
            new.eval()?;
            assert_eq!(old.shape(), new.shape());
            for (&expected, &actual) in old
                .try_as_slice::<f32>()?
                .iter()
                .zip(new.try_as_slice::<f32>()?)
            {
                assert!(
                    (actual - expected).abs() <= 1e-5 + 1e-4 * expected.abs(),
                    "shape {batch}/{source}/{length}: {actual} != {expected}"
                );
            }
        }
        Ok(())
    })
}
#[test]
fn all_fixtures_on_real_metal() -> Result<()> {
    with_device(Device::gpu(), || {
        let fixture = Fixture::parse(include_bytes!("../../../tests/fixtures/operators-v1.json"))?;
        assert!(!fixture.torch_version.is_empty());
        assert_eq!(fixture.cases.len(), 18);
        for case in &fixture.cases {
            let output = Prepared::new(case)?.execute()?;
            output.eval()?;
            let result = check_output(&output, &case.expected)?;
            assert!(result.passed, "{}: {result:?}", case.name);
        }
        Ok(())
    })
}
#[test]
fn invalid_parameters_and_masks() -> Result<()> {
    with_device(Device::gpu(), || {
        let x = Array::from_slice(&[1f32; 12], &[1, 3, 4]);
        assert!(ops::group_norm(&x, 3, 1e-5).is_err());
        assert!(ops::area1d(&x, 0).is_err());
        assert!(ops::linear1d(&x, 0).is_err());
        assert!(ops::layer_norm(&x, f64::NAN).is_err());
        let odd = Array::from_slice(&[1f32; 3], &[1, 1, 1, 3]);
        assert!(ops::rope(&odd, &odd, &odd).is_err());
        let mut fixture =
            Fixture::parse(include_bytes!("../../../tests/fixtures/operators-v1.json"))?;
        let attention = fixture
            .cases
            .iter_mut()
            .find(|c| c.inputs.contains_key("mask"))
            .unwrap();
        attention.inputs.get_mut("mask").unwrap().data.fill(0.);
        assert!(Prepared::new(attention).is_err());
        Ok(())
    })
}

#[test]
fn area_gather_matches_scalar_with_nonfinite_values() -> Result<()> {
    with_device(Device::gpu(), || {
        for (batch, source, length) in [
            (1_usize, 89_usize, 1_usize),
            (1, 89, 2),
            (1, 89, 3),
            (1, 89, 13),
            (1, 89, 50),
            (1, 13, 89),
            (4, 89, 13),
            (2, 37, 67),
        ] {
            for nonfinite in [false, true] {
                let mut data: Vec<f32> = (0..batch * source * 8)
                    .map(|i| ((i * 73 % 509) as f32 - 254.) / 37.)
                    .collect();
                if nonfinite {
                    data[0] = f32::NAN;
                    data[1] = f32::INFINITY;
                    data[2] = f32::NEG_INFINITY;
                }
                let x = Array::from_slice(&data, &[batch as i32, source as i32, 8]);
                let mut bins = Vec::with_capacity(length);
                for i in 0..length {
                    let start = i * source / length;
                    let end = ((i + 1) * source).div_ceil(length);
                    bins.push(
                        x.try_index((.., start as i32..end as i32, ..))?
                            .mean_axis(1, true)?,
                    );
                }
                let old = mlx_rs::ops::concatenate(&bins, 1)?;
                let new = ops::area1d(&x, length)?;
                old.eval()?;
                new.eval()?;
                assert_eq!(old.shape(), new.shape());
                for (&expected, &actual) in old
                    .try_as_slice::<f32>()?
                    .iter()
                    .zip(new.try_as_slice::<f32>()?)
                {
                    assert!(
                        expected.is_nan() && actual.is_nan()
                            || expected == actual
                            || (expected.is_finite()
                                && actual.is_finite()
                                && (actual - expected).abs() <= 1e-5 + 1e-4 * expected.abs()),
                        "shape {batch}/{source}/{length}, nonfinite={nonfinite}: {actual} != {expected}"
                    );
                }
            }
        }
        Ok(())
    })
}
