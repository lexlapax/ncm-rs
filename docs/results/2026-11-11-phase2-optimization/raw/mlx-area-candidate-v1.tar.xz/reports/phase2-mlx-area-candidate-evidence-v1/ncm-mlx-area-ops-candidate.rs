//! FP32 compositions, BLC activations, explicit upstream weight-layout conversion.
use mlx_rs::{
    Array,
    ops::{
        self,
        indexing::{Ellipsis, TryIndexOp},
    },
};
pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn epsilon(epsilon: f64) -> Result<Array> {
    if !epsilon.is_finite() || epsilon <= 0. || epsilon > f32::MAX as f64 {
        return Err("invalid epsilon".into());
    }
    Ok(Array::from_f32(epsilon as f32))
}
pub fn layer_norm(x: &Array, eps: f64) -> Result<Array> {
    let centered = x.subtract(x.mean_axis(-1, true)?)?;
    Ok(centered.multiply(
        centered
            .square()?
            .mean_axis(-1, true)?
            .add(epsilon(eps)?)?
            .rsqrt()?,
    )?)
}
pub fn rms_norm(x: &Array, eps: f64) -> Result<Array> {
    Ok(x.multiply(
        x.square()?
            .mean_axis(-1, true)?
            .add(epsilon(eps)?)?
            .rsqrt()?,
    )?)
}
pub fn group_norm(x: &Array, groups: usize, eps: f64) -> Result<Array> {
    let &[b, l, c] = x.shape() else {
        return Err("GroupNorm requires BLC".into());
    };
    let g = i32::try_from(groups)?;
    if g <= 0 || c % g != 0 {
        return Err("invalid normalization groups".into());
    }
    let flat =
        x.swap_axes(1, 2)?
            .reshape(&[b, g, (c / g).checked_mul(l).ok_or("shape overflow")?])?;
    Ok(layer_norm(&flat, eps)?
        .reshape(&[b, c, l])?
        .swap_axes(1, 2)?)
}
pub fn conv1d(x: &Array, w: &Array, stride: usize, padding: usize) -> Result<Array> {
    if stride == 0 {
        return Err("zero stride".into());
    }
    Ok(ops::conv1d(
        x,
        w.transpose_axes(&[0, 2, 1])?,
        i32::try_from(stride)?,
        i32::try_from(padding)?,
        1,
        1,
    )?)
}
pub fn conv_transpose1d(x: &Array, w: &Array, stride: usize, padding: usize) -> Result<Array> {
    if stride == 0 {
        return Err("zero stride".into());
    }
    // Upstream [in,out,k] -> MLX [out,k,in].
    Ok(ops::conv_transpose1d(
        x,
        w.transpose_axes(&[1, 2, 0])?,
        i32::try_from(stride)?,
        i32::try_from(padding)?,
        1,
        0,
        1,
    )?)
}
fn lengths(x: &Array, length: usize) -> Result<(usize, i32)> {
    if x.shape().len() != 3 || x.shape()[1] <= 0 || length == 0 || length > 1_000_000 {
        return Err("invalid BLC resampling shape/length".into());
    }
    Ok((length, x.shape()[1]))
}
fn area_scalar(x: &Array, length: usize, source: usize) -> Result<Array> {
    let mut bins = Vec::with_capacity(length);
    for i in 0..length {
        let start = i * source / length;
        let end = ((i + 1) * source).div_ceil(length);
        bins.push(
            x.try_index((.., start as i32..end as i32, ..))?
                .mean_axis(1, true)?,
        );
    }
    Ok(ops::concatenate(&bins, 1)?)
}
pub fn area1d(x: &Array, length: usize) -> Result<Array> {
    let (length, source) = lengths(x, length)?;
    let source = source as usize;
    if length <= 2 {
        return area_scalar(x, length, source);
    }
    let bins: Vec<_> = (0..length)
        .map(|i| (i * source / length, ((i + 1) * source).div_ceil(length)))
        .collect();
    let width = bins.iter().map(|(a, b)| b - a).max().ok_or("empty bins")?;
    let count = length.checked_mul(width).ok_or("shape overflow")?;
    let shape = x.shape();
    let elements = count
        .checked_mul(usize::try_from(shape[0])?)
        .and_then(|n| n.checked_mul(usize::try_from(shape[2]).ok()?));
    if elements.is_none_or(|n| n > 4 * 1024 * 1024) || i32::try_from(count).is_err() {
        return area_scalar(x, length, source);
    }
    let mut indices = Vec::with_capacity(count);
    let mut mask = Vec::with_capacity(count);
    let mut divisor = Vec::with_capacity(length);
    for (start, end) in bins {
        divisor.push((end - start) as f32);
        for j in 0..width {
            indices.push(i32::try_from((start + j).min(end - 1))?);
            mask.push(start + j < end);
        }
    }
    let output = i32::try_from(length)?;
    let width = i32::try_from(width)?;
    let values = x
        .take_axis(Array::from_slice(&indices, &[i32::try_from(count)?]), 1)?
        .reshape(&[shape[0], output, width, shape[2]])?;
    let values = ops::select(
        Array::from_slice(&mask, &[1, output, width, 1]),
        values,
        Array::from_f32(0.),
    )?;
    Ok(values
        .sum_axis(2, false)?
        .divide(Array::from_slice(&divisor, &[1, output, 1]))?)
}

pub fn linear1d(x: &Array, length: usize) -> Result<Array> {
    let (length, source) = lengths(x, length)?;
    let mut low = Vec::with_capacity(length);
    let mut high = Vec::with_capacity(length);
    let mut left = Vec::with_capacity(length);
    let mut right = Vec::with_capacity(length);
    for i in 0..length {
        let position = ((i as f64 + 0.5) * f64::from(source) / length as f64 - 0.5).max(0.);
        let lo = (position.floor() as i32).min(source - 1);
        let weight = position - lo as f64;
        low.push(lo);
        high.push((lo + 1).min(source - 1));
        left.push((1. - weight) as f32);
        right.push(weight as f32);
    }
    let length = i32::try_from(length)?;
    let a = x.take_axis(Array::from_slice(&low, &[length]), 1)?;
    let b = x.take_axis(Array::from_slice(&high, &[length]), 1)?;
    Ok(a.multiply(Array::from_slice(&left, &[1, length, 1]))?
        .add(b.multiply(Array::from_slice(&right, &[1, length, 1]))?)?)
}
/// Additive mask; caller must reject rows with no allowed keys before dispatch.
pub fn attention(q: &Array, k: &Array, v: &Array, mask: &Array) -> Result<Array> {
    if q.shape().len() != 4 || q.shape()[3] <= 0 {
        return Err("attention requires BHLD".into());
    }
    let scores = q
        .matmul(k.swap_axes(-1, -2)?)?
        .multiply(Array::from_f32(1. / (q.shape()[3] as f32).sqrt()))?
        .add(mask)?;
    Ok(ops::softmax_axis(&scores, -1, true)?.matmul(v)?)
}
pub fn rope(x: &Array, cos: &Array, sin: &Array) -> Result<Array> {
    let width = *x.shape().last().ok_or("empty RoPE shape")?;
    if width <= 0 || width % 2 != 0 {
        return Err("RoPE needs even positive head width".into());
    }
    let first = x.try_index((Ellipsis, ..width / 2))?;
    let second = x.try_index((Ellipsis, width / 2..))?.negative()?;
    Ok(x.multiply(cos)?
        .add(ops::concatenate(&[second, first], -1)?.multiply(sin)?)?)
}
