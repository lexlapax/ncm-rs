"""Offline inspection of the failed fixed read-only attempt; never collect or qualify it."""
import hashlib
import json
from pathlib import Path
import re
import sys
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools/bench'))
from validate_readonly_telemetry import cpu_records, gpu_records, utc_ns
from cupti_trace_boundaries import ELAPSED

collection = ROOT / 'reports/phase2-linux-readonly-trace-v1'
launch = ROOT / 'reports/phase2-linux-readonly-trace-v1-launch'
manifest_raw = (launch / 'preparation.json').read_bytes()
manifest = json.loads(manifest_raw)
sequence = json.loads((collection / 'sequence/sequence-result.json').read_bytes())
supervisor = json.loads((launch / 'supervision/supervisor.json').read_bytes())
outer = json.loads((launch / 'supervisor.receipt.json').read_bytes())
telemetry = json.loads((collection / 'telemetry/telemetry.json').read_bytes())
assert outer['direct_child_reaped'] and supervisor['cleanup']['complete']
assert not supervisor['cleanup']['remaining'] and telemetry['status'] == 'complete'
assert sequence['status'] == 'failed' and len(sequence['jobs']) == 3
assert not (launch / 'completion').exists() and not (launch / 'entry-result.json').exists()

capture = collection / 'sequence/03-AT.capture'
digest = hashlib.sha256()
prefixes, driver_names = Counter(), Counter()
size = complete_lines = partial_lines = max_line_bytes = 0
elapsed = []
with capture.open('rb') as file:
    while line := file.readline(1024 * 1024):
        assert len(line) < 1024 * 1024, 'unexpected huge line; do not silently split it'
        digest.update(line)
        size += len(line)
        max_line_bytes = max(max_line_bytes, len(line))
        if not line.endswith(b'\n'):
            partial_lines += 1
            assert not file.read(1), 'non-final partial line'
            continue
        complete_lines += 1
        token = line.split(maxsplit=1)
        prefixes[(token[0].decode('ascii', 'replace') if token else '(blank)')] += 1
        if line.startswith(b'DRIVER '):
            name = re.search(rb'"([^"]+)"', line)
            assert name is not None
            driver_names[name[1].decode('ascii')] += 1
            if name[1].decode('ascii') in ELAPSED:
                match = re.search(rb'^DRIVER \[ (\d+), (\d+) \]', line)
                assert match is not None
                elapsed.append([int(match[1]), int(match[2])])
receipt = sequence['jobs'][2]['receipt']
assert size == capture.stat().st_size == receipt['captured_bytes'] == 1024**3
assert digest.hexdigest() == receipt['capture_sha256']

source = next(item['sha256'] for item in manifest['tool_identities']
              if item['path'].endswith('/tools/bench/sample_linux_cpu.py'))
cpu_raw = (collection / 'telemetry/cpu.jsonl').read_bytes()
gpu_raw = (collection / 'telemetry/gpu.csv').read_bytes()
assert hashlib.sha256(cpu_raw).hexdigest() == telemetry['cpu_receipt']['report_capture']['sha256']
assert hashlib.sha256(gpu_raw).hexdigest() == telemetry['gpu_sha256']
validation = {}
cpu = gpu = None
try:
    cpu = cpu_records(cpu_raw, source)
    validation['cpu_contents'] = 'pass'
except (ValueError, KeyError, TypeError) as error:
    validation['cpu_contents'] = {'error': type(error).__name__, 'message': str(error)}
try:
    gpu = gpu_records(gpu_raw, manifest['gpu']['uuid'], manifest['timezone']['zone'])
    validation['gpu_contents'] = 'pass'
except (ValueError, KeyError, TypeError) as error:
    validation['gpu_contents'] = {'error': type(error).__name__, 'message': str(error)}
if cpu is not None:
    validation.update(cpu_samples=len(cpu['samples']), cpu_completion=cpu['completion'],
                      missing_cpu_optional=cpu['missing_optional'], unavailable_cpu_activity=cpu['unavailable_activity'])
if gpu is not None:
    validation.update(gpu_samples=len(gpu), gpu_first_utc=gpu[0]['utc'], gpu_last_utc=gpu[-1]['utc'])
if cpu is not None and gpu is not None:
    validation['attempted_receipt_windows'] = [
        {'condition': job['condition'], 'status': job['receipt']['status'],
         'cpu_bracketed': cpu['utc_ns'][0] <= utc_ns(job['receipt']['started_utc'])
                          < utc_ns(job['receipt']['finished_utc']) <= cpu['utc_ns'][-1],
         'gpu_bracketed': gpu[0]['utc_ns'] <= utc_ns(job['receipt']['started_utc'])
                          < utc_ns(job['receipt']['finished_utc']) <= gpu[-1]['utc_ns']}
        for job in sequence['jobs']]
    validation['cpu_gap_seconds'] = [(b-a)/1e9 for a,b in zip(cpu['utc_ns'],cpu['utc_ns'][1:])]
    validation['gpu_gap_seconds'] = [(b['utc_ns']-a['utc_ns'])/1e9 for a,b in zip(gpu,gpu[1:])]
validation['full_twelve_job_validation_passed'] = False

result = {
    'schema_version': 1, 'status': 'failed_attempt_offline_inspection',
    'candidate_head': manifest['expected_candidate_head'],
    'preparation_sha256': hashlib.sha256(manifest_raw).hexdigest(),
    'outer_started_utc': outer['started_utc'], 'outer_finished_utc': outer['finished_utc'],
    'outer_pid': outer['pid'], 'outer_child_reaped': outer['direct_child_reaped'],
    'supervisor_cleanup': supervisor['cleanup'], 'subreaper_restored': supervisor['subreaper_restored'],
    'jobs': [{'condition': j['condition'], 'pid': j['receipt']['pid'], 'status': j['receipt']['status'],
              'issues': j['receipt']['issues'], 'returncode': j['receipt']['returncode'],
              'direct_child_reaped': j['receipt']['direct_child_reaped']} for j in sequence['jobs']],
    'capture': {'path': str(capture.relative_to(ROOT)), 'sha256': digest.hexdigest(), 'bytes': size,
                'observed_bytes': receipt['observed_bytes'], 'complete_lines': complete_lines,
                'trailing_partial_lines': partial_lines, 'max_line_bytes': max_line_bytes,
                'line_prefix_counts': dict(sorted(prefixes.items())),
                'driver_call_counts': dict(sorted(driver_names.items())),
                'serialized_elapsed_query_count': len(elapsed), 'elapsed_query_host_intervals_ns': elapsed,
                'complete_trace': False, 'ordinal_trial_joins_qualified': False},
    'telemetry': validation,
    'cpu_sha256': hashlib.sha256(cpu_raw).hexdigest(), 'gpu_sha256': hashlib.sha256(gpu_raw).hexdigest(),
    'frozen_input_postflight_executed': False, 'reported_codec_outputs_qualified': False,
    'performance_acceptance_evaluated': False, 'gpu_policy_changed': False,
    'scope': 'Failure inspection only. Streamed counts describe serialized complete lines before truncation, '
             'not all device/API activity, qualified boundaries/trials, independent producers, continuous coverage '
             'or a causal explanation. Separate telemetry content checks do not pass the twelve-job gate. '
             'No retry, exclusions, widened limits or acceptance substitution.'}
with (ROOT / 'reports/phase2-readonly-failure-inspection-v2.json').open('x') as file:
    json.dump(result, file, indent=2, allow_nan=False)
    file.write('\n')
print(json.dumps({k: result[k] for k in ('status','jobs','outer_started_utc','outer_finished_utc')},indent=2))
print('trace bytes/complete lines/elapsed queries:', size, complete_lines, len(elapsed))
print('telemetry content checks:', validation['cpu_contents'], validation['gpu_contents'])
