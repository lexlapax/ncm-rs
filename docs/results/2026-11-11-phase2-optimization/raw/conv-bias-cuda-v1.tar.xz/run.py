import hashlib,json,os,pathlib,subprocess,time
out=pathlib.Path('reports/phase2-conv-bias-diagnostic-v1'); plan=json.loads((out/'plan.json').read_text()); bins={'baseline':'/tmp/ncm-conv-bias-diagnostic/baseline-codec-bench','candidate':'target/release/examples/codec_bench'}
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
result={'plan_sha256':sha(out/'plan.json'),'binaries':{k:sha(v) for k,v in bins.items()},'runs':[]}; counts={'baseline':0,'candidate':0}
for label in plan['order']:
 counts[label]+=1; path=out/(label+'-'+str(counts[label])+'.json'); cmd=['taskset','-c','2',bins[label],'artifacts/canonical/sudoku-easy-qualified','tests/fixtures/codec-bench-v1.json',str(path)]; start=time.time_ns()
 try:
  p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=plan['timeout_seconds_per_process']); status=p.returncode
  (out/(label+'-'+str(counts[label])+'.stderr')).write_bytes(p.stderr)
 except subprocess.TimeoutExpired: status='timeout'
 result['runs'].append({'label':label,'number':counts[label],'returncode':status,'elapsed_ns':time.time_ns()-start,'result_sha256':sha(path) if path.exists() else None}); (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
 if status!=0: raise SystemExit('diagnostic stopped on failure')
