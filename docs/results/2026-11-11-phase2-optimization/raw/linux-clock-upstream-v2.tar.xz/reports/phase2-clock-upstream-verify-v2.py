"""Read-only current upstream inspection; no target imports or hardware access."""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools/bench'))
from readonly_trace_preflight import file_identity, require
from readonly_trace_runtime import metadata_probe

UPSTREAM='c70274273f489abc73832b2b98584a8483b6b203'
TREE=ROOT/'.reference/upstream-ncm'
OUT=ROOT/'reports/phase2-clock-upstream-verification-v2'
GIT=Path('/usr/bin/git').resolve(strict=True)
ENV={'PATH':os.defpath,'HOME':str(Path.home()),'LANG':'C','LC_ALL':'C','PYTHONNOUSERSITE':'1',
     'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0','GIT_TERMINAL_PROMPT':'0'}
# Reviewed local configuration has only core/remote/branch settings, no filters,
# fsmonitor, includes or executable helpers. Pin before any further Git subprocess.
CONFIG_SHA='e11456e4bc00390f8f42b98eac749b4e829771b7f59283376b33b8b9ca0d630c'
os.umask(0o077)
require(TREE.resolve(strict=True)==TREE and (TREE/'.git').is_dir(),'canonical standalone upstream required')
OUT.mkdir(mode=0o700)
config=file_identity(TREE/'.git/config',CONFIG_SHA)
git=file_identity(GIT); index=file_identity(TREE/'.git/index')
receipts={}
def probe(name,args):
    text,receipt=metadata_probe([str(GIT),'--no-replace-objects','--no-optional-locks','-c','core.fsmonitor=false',
        '-c','core.untrackedCache=false','-C',str(TREE),*args],ROOT,ENV,OUT,name)
    receipts[name]=receipt
    return text

def nul(text):
    require(not text or text.endswith('\0'),'truncated Git listing')
    return text.split('\0')[:-1] if text else []

require(probe('head-before',['rev-parse','HEAD']).strip()==UPSTREAM,'upstream HEAD differs')
probe('raw-commit',['cat-file','commit',UPSTREAM])
commit=(OUT/'raw-commit.txt').read_bytes()
require(hashlib.sha1(b'commit '+str(len(commit)).encode()+b'\0'+commit).hexdigest()==UPSTREAM,
        'raw commit object differs from pinned SHA-1')
require(probe('top-level',['rev-parse','--show-toplevel']).strip()==str(TREE),'unexpected upstream worktree root')
require(probe('status-before',['status','--porcelain=v1','-z','--untracked-files=all'])=='','upstream dirty/untracked')
flags=nul(probe('index-flags',['ls-files','-v','-z']))
require(flags and len(flags)<=512 and all(row.startswith('H ') for row in flags),'hidden or unsupported index flags')
flag_paths=[row[2:] for row in flags]
head=nul(probe('head-tree',['ls-tree','-r','-z','--full-tree',UPSTREAM]))
tracked={}
for row in head:
    prefix,name=row.split('\t',1); mode,kind,oid=prefix.split()
    path=TREE/name
    require(mode in ('100644','100755') and kind=='blob' and len(oid)==40
            and name not in tracked and path.is_relative_to(TREE) and '..' not in Path(name).parts
            and path.resolve(strict=True)==path,'unsupported upstream source entry')
    tracked[name]=(mode,oid)
require(set(tracked)==set(flag_paths) and len(flag_paths)==len(tracked),'index/HEAD path sets differ')
staged=nul(probe('index-entries',['ls-files','--stage','-z']))
expected=[]
for row in staged:
    prefix,name=row.split('\t',1); mode,oid,stage=prefix.split()
    require(stage=='0' and tracked.get(name)==(mode,oid),'index differs from pinned tree')
    expected.append(name)
require(set(expected)==set(tracked) and len(expected)==len(tracked),'index entries differ')
ignored=nul(probe('ignored',['ls-files','--others','--ignored','--exclude-standard','-z']))
inventory=[]; total=0
for name in sorted(tracked):
    path=TREE/name; current=path.stat(follow_symlinks=False)
    require(stat.S_ISREG(current.st_mode) and current.st_size<=8*1024**2,'nonregular/oversized upstream source')
    total+=current.st_size; require(total<=64*1024**2,'upstream source inventory exceeds bound')
    inventory.append((name,current))
files=[]
for name,before in inventory:
    path=TREE/name; identity=file_identity(path,size=before.st_size)
    require((identity['device'],identity['inode'])==(before.st_dev,before.st_ino),'source replaced while hashing')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as source:
        current=os.fstat(source.fileno())
        require(stat.S_ISREG(current.st_mode) and (current.st_dev,current.st_ino)==(before.st_dev,before.st_ino),
                'source identity changed before Git blob check')
        raw=source.read(before.st_size+1)
    require(len(raw)==before.st_size and hashlib.sha256(raw).hexdigest()==identity['sha256'],'source changed between reads')
    blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    require(blob==tracked[name][1],'upstream source bytes differ from pinned Git blob')
    require(bool(before.st_mode & 0o111)==(tracked[name][0]=='100755'),'upstream source executable mode differs')
    files.append(dict(relative_path=name,git_mode=tracked[name][0],git_blob_sha1=blob,identity=identity))
require(probe('head-after',['rev-parse','HEAD']).strip()==UPSTREAM,'upstream HEAD changed')
require(probe('status-after',['status','--porcelain=v1','-z','--untracked-files=all'])=='','upstream changed/dirty')
for identity in (git,config,index):
    current=file_identity(identity['path'],identity['sha256'],identity['bytes'])
    require(all(current[k]==identity[k] for k in ('path','sha256','bytes','device','inode')),
            'Git utility/config/index changed')
for name,before in inventory:
    path=TREE/name; current=path.stat(follow_symlinks=False)
    require(path.resolve(strict=True)==path and all(getattr(before,k)==getattr(current,k) for k in
        ('st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns','st_mode')),'source changed during inspection')
result=dict(schema_version=1,current_upstream_snapshot_verified=True,upstream_commit=UPSTREAM,
    tracked_clean=True,untracked_count=0,tracked_file_count=len(files),tracked_bytes=total,
    replacement_objects_disabled=True,raw_commit_sha1_verified=True,
    ignored_entry_count=len(ignored),ignored_entries_inspected=False,git_identity=git,config_identity=config,
    index_identity=index,files=files,receipts=receipts,launch_ready=False,python_import_closure_verified=False,
    historical_interpreter_library_bytes_verified=False,atomic_snapshot_verified=False,
    scope='Current pinned Git tree/index and tracked regular-file bytes only. Private raw Git listings retained. '
          'Ignored entries are counted, not qualified; no source import, Python bytecode/native closure, '
          'atomic snapshot, benchmark or launch-readiness proof. Recheck during fresh full preparation.')
with (OUT/'upstream.json').open('x') as output: json.dump(result,output,indent=2); output.write('\n')
print(json.dumps({k:result[k] for k in ('upstream_commit','tracked_file_count','tracked_bytes','tracked_clean',
    'untracked_count','ignored_entry_count','launch_ready','python_import_closure_verified')},sort_keys=True))
