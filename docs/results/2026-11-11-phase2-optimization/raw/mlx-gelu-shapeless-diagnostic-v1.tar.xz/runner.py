import hashlib,json,os,subprocess,threading,time
from pathlib import Path
r=Path.home()/'projects/lexlapax/ncm-rs';out=r/'.reference/phase2-mlx-gelu-shapeless-run-v1';out.mkdir(mode=0o700,exist_ok=False)
bin=r/'.reference/phase2-mlx-gelu-shapeless-target-v1/release/examples/mlx_gelu_toggle_diagnostic';src=r/'.reference/phase2-mlx-gelu-shapeless-v1/crates/ncm-backend-mlx/examples/mlx_gelu_toggle_diagnostic.rs'
meta={'binary_sha256':hashlib.sha256(bin.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'commands':[],'thermal_before':subprocess.check_output(['/usr/bin/pmset','-g','therm'],text=True)};stop=threading.Event()
def sample():
 try:
  with (out/'activity.jsonl').open('x') as f:
   while not stop.is_set():
    rows=[]
    for line in subprocess.check_output(['/bin/ps','-Ao','pcpu=,comm='],text=True).splitlines():
     cpu,name=line.split(None,1);rows.append({'cpu_percent':float(cpu),'name':Path(name).name})
    f.write(json.dumps({'time':time.time(),'top_cpu':sorted(rows,key=lambda x:x['cpu_percent'],reverse=True)[:12]})+'\n');f.flush();stop.wait(.5)
 except Exception as e:meta['activity_error']=str(e)
t=threading.Thread(target=sample);t.start()
try:
 for i in range(1,4):
  command=[str(bin),str(r/'artifacts/canonical/sudoku-easy-qualified'),str(out/f'run-{i}.json')];e={'argv':command,'start':time.time()};meta['commands'].append(e)
  subprocess.run(command,cwd=r/'.reference/phase2-mlx-gelu-shapeless-v1',env={'PATH':'/usr/bin:/bin'},timeout=120,check=True);e['end']=time.time()
finally:
 stop.set();t.join();meta['thermal_after']=subprocess.check_output(['/usr/bin/pmset','-g','therm'],text=True);(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
if 'activity_error' in meta:raise RuntimeError(meta['activity_error'])
