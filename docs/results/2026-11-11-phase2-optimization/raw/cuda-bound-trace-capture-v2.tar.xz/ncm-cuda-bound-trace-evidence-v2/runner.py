"""Fresh CUDA trace and qualification with before/after local identities."""
import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path('/home/lexlapax/projects/lexlapax/ncm-rs');os.chdir(root)
out=Path('/tmp/ncm-cuda-bound-trace-evidence-v2');trace=root/'reports/phase2-codec/cuda-bound-provenance-v2';qual=root/'reports/phase2-cuda-bound-qualification-v2.json'
binpath=root/'target/release/examples/codec_trace';oracle=root/'reports/phase2-oracle/v1/sudoku-cuda';artifact=root/'artifacts/canonical/sudoku-easy-qualified'
paths={'binary':binpath,'source':root/'crates/ncm-backend-cuda/src/fused_projection.rs','bounded':root/'crates/ncm-backend-cuda/src/fused_projection/bounded.rs','manifest':artifact/'manifest.json'}
expected={'binary':'2714ef7303eab002c838131d8729c78d2a7a1aee739db9e3f4ef4fd8a62ca181','source':'92686330ae3c661d60ed291b68a069b15ca25a1103c444deb502f19708014950','bounded':'5e5cd0fe6176dd3bd0079a73fb36e5687fa09e49f217564cffc5e56ae0740327','manifest':'ad6a99ad7d5ccc069e0fedf26a85f755e06cd76590463e1e04e17363e35d9832'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def identities():return {k:sha(v) for k,v in paths.items()}
if trace.exists() or qual.exists() or out.exists():raise ValueError('destination exists')
if identities()!=expected:raise ValueError('initial source or binary identity differs')
if any(os.environ.get(k) for k in ('LD_PRELOAD','CUDA_INJECTION64_PATH','CUDA_INJECTION32_PATH','CUDA_VISIBLE_DEVICES')):raise ValueError('injected or remapped environment')
out.mkdir(mode=0o700);now=lambda:datetime.now(timezone.utc).isoformat()
meta={'status':'running','scope':'source-bound trained CUDA trace capture, not timing or memory acceptance','started':now(),'identities_before':identities(),'commands':[]}
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(argv,label):
 row={'label':label,'argv':list(map(str,argv)),'start':now()};meta['commands'].append(row);save()
 with (out/f'{label}.stdout').open('xb') as a,(out/f'{label}.stderr').open('xb') as b:
  child=subprocess.run(argv,cwd=root,stdout=a,stderr=b,timeout=300,check=False)
 row['returncode']=child.returncode;row['finish']=now();save()
 if child.returncode:raise RuntimeError(label+' failed')
save()
try:
 run([str(binpath),str(artifact),str(oracle),str(trace),'cuda'],'capture')
 run([str(root/'.reference/venv/bin/python'),str(root/'tools/reference/qualify_codec.py'),str(oracle),str(trace),str(qual)],'qualification')
 q=json.loads(qual.read_bytes())
 if not q['all_passed'] or q['trace_count']!=642 or sum(x['decisions'] for x in q['selections'].values())!=2500:raise ValueError('qualification incomplete')
 if q['candidate_report_sha256']!=sha(trace/'report.json') or q['right_trace_sha256']!=sha(trace/'traces.safetensors'):raise ValueError('capture hashes differ')
 meta['identities_after']=identities()
 if meta['identities_after']!=expected:raise ValueError('source or binary changed during capture')
 meta['qualification_sha256']=sha(qual);meta['trace_sha256']=q['right_trace_sha256'];meta['candidate_report_sha256']=q['candidate_report_sha256'];meta['status']='complete'
except Exception as e:meta['status']='failed';meta['error']=str(e);raise
finally:meta['finished']=now();save()
print('bound CUDA capture and qualification complete')
