import hashlib,json,pathlib,subprocess,time
out=pathlib.Path('reports/phase2-tiny-reserve-diagnostic-v1'); plan=json.loads((out/'plan.json').read_text());bins={'baseline':'/tmp/ncm-tiny-reserve-v1/baseline-asset-bench','candidate':'target/release/examples/asset_bench'}
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
r={'plan_sha256':sha(out/'plan.json'),'binaries':{k:sha(v) for k,v in bins.items()},'runs':[]};counts={'baseline':0,'candidate':0}
for label in plan['order']:
 counts[label]+=1;p=out/(label+'-'+str(counts[label])+'.json');cmd=['taskset','-c','2',bins[label],'artifacts/canonical/tokenizers-qualified','tests/fixtures/tokenizers-v1.json','tinystories',str(p)];start=time.time_ns();x=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120);r['runs'].append({'label':label,'number':counts[label],'returncode':x.returncode,'elapsed_ns':time.time_ns()-start,'result_sha256':sha(p) if p.exists() else None});(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');
 if x.returncode: (out/'failure.stderr').write_bytes(x.stderr);raise SystemExit('stopped on failure')
