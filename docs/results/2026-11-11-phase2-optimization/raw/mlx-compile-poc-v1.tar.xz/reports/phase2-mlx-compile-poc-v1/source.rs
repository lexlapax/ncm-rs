//! Isolated, pure layer-normalization compilation diagnostic.
use mlx_rs::{Array, Device, error::Exception, memory, transforms::compile::compile, with_device};
use serde_json::json;
use std::{error::Error, fs, path::Path, time::Instant};
type Result<T> = std::result::Result<T, Box<dyn Error>>;
fn graph((x, eps): (&Array, &Array)) -> std::result::Result<Array, Exception> {
    let centered = x.subtract(x.mean_axis(-1, true)?)?;
    centered.multiply(centered.square()?.mean_axis(-1, true)?.add(eps)?.rsqrt()?)
}
fn run() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 2 || cfg!(debug_assertions) || Path::new(&args[1]).exists() {
        return Err("usage (release): mlx_compile_poc NEW_REPORT".into());
    }
    let mut rows = Vec::new();
    for (batch, length, channels) in [(1_usize, 89_usize, 64_usize), (1, 89, 256), (4, 89, 256)] {
        let input: Vec<f32> = (0..batch * length * channels)
            .map(|i| ((i * 73 % 509) as f32 - 254.) / 37.)
            .collect();
        let x = Array::from_slice(&input, &[batch as i32, length as i32, channels as i32]);
        let eps = Array::from_f32(1e-6);
        x.eval()?;
        eps.eval()?;
        memory::clear_cache()?;
        memory::reset_peak_memory()?;
        let mut compiled = compile(graph, None);
        let start = Instant::now();
        let compiled_first = compiled((&x, &eps))?;
        let first_graph_ms = start.elapsed().as_secs_f64() * 1000.;
        compiled_first.eval()?;
        let first_total_ms = start.elapsed().as_secs_f64() * 1000.;
        let first_peak = memory::peak_memory()?;
        let first_cache = memory::cache_memory()?;
        let first_active = memory::active_memory()?;
        let old = graph((&x, &eps))?;
        old.eval()?;
        let mut max_abs = 0f32;
        for (&a, &b) in old
            .try_as_slice::<f32>()?
            .iter()
            .zip(compiled_first.try_as_slice::<f32>()?)
        {
            let diff = (a - b).abs();
            max_abs = max_abs.max(diff);
            if diff > 1e-5 + 1e-4 * a.abs() {
                return Err(format!("mismatch {batch}/{length}/{channels}: {a} vs {b}").into());
            }
        }
        drop(old);
        drop(compiled_first);
        let mut plain_graph = Vec::new();
        let mut plain_total = Vec::new();
        let mut compiled_graph = Vec::new();
        let mut compiled_total = Vec::new();
        for i in 0..35 {
            let start = Instant::now();
            let y = graph((&x, &eps))?;
            let g = start.elapsed().as_secs_f64() * 1000.;
            y.eval()?;
            let t = start.elapsed().as_secs_f64() * 1000.;
            if i >= 5 {
                plain_graph.push(g);
                plain_total.push(t);
            }
            let start = Instant::now();
            let z = compiled((&x, &eps))?;
            let g = start.elapsed().as_secs_f64() * 1000.;
            z.eval()?;
            let t = start.elapsed().as_secs_f64() * 1000.;
            if i >= 5 {
                compiled_graph.push(g);
                compiled_total.push(t);
            }
        }
        rows.push(json!({"batch":batch,"length":length,"channels":channels,"first_graph_ms":first_graph_ms,"first_total_ms":first_total_ms,
            "first_peak_bytes":first_peak,"first_cache_bytes":first_cache,"first_active_bytes":first_active,
            "final_peak_bytes":memory::peak_memory()?,"final_cache_bytes":memory::cache_memory()?,"final_active_bytes":memory::active_memory()?,
            "max_abs_difference":max_abs,"plain_graph_ms":plain_graph,"plain_total_ms":plain_total,"compiled_graph_ms":compiled_graph,"compiled_total_ms":compiled_total}));
    }
    serde_json::to_writer_pretty(
        fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&args[1])?,
        &json!({"schema_version":1,"warmups":5,"trials":30,"cases":rows,"scope":"isolated pure layer norm; explicit input and epsilon; first call includes compilation; not an acceptance benchmark"}),
    )?;
    Ok(())
}
fn main() -> Result<()> {
    with_device(Device::gpu(), run)
}
