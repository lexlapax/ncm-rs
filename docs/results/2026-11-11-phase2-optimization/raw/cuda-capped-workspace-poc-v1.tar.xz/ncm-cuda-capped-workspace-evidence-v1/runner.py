import hashlib,json,os,pathlib,subprocess,threading,time
from datetime import datetime,timezone
root=pathlib.Path('/home/lexlapax/projects/lexlapax/ncm-rs')
out=pathlib.Path('/tmp/ncm-cuda-capped-workspace-evidence-v1')
binpath=pathlib.Path('/tmp/ncm-cuda-capped-workspace-poc-v1')
source=pathlib.Path('/tmp/ncm-cuda-capped-workspace-poc-v1.cpp')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sha(source)!='af7b9d06a1ca3d0c30db8eeb1c91394993e5d170e924d7b1948d1a3a8061e3b3' or sha(binpath)!='b7516518db17e79b1ebfca12f3a351b60f97237f44d6cfb4d30d03fa1e1d22ed':raise ValueError('diagnostic identity differs')
if any(os.environ.get(k) for k in ('LD_PRELOAD','CUDA_INJECTION64_PATH','CUDA_INJECTION32_PATH','CUDA_VISIBLE_DEVICES')):raise ValueError('instrumented or remapped environment')
out.mkdir(mode=0o700)
meta={'status':'running','source_sha256':sha(source),'binary_sha256':sha(binpath),'runs':[],'activity_errors':[],'device':subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version','--format=csv,noheader'],text=True).strip(),'nvcc':subprocess.check_output(['/opt/cuda/bin/nvcc','--version'],text=True)}
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
stop=threading.Event()
def sample():
 try:
  with (out/'activity.jsonl').open('x') as f:
   while not stop.is_set():
    gpu=subprocess.check_output(['nvidia-smi','--query-gpu=timestamp,temperature.gpu,utilization.gpu,memory.used,clocks.sm,power.draw','--format=csv,noheader,nounits'],text=True).strip()
    entries=[]
    for line in subprocess.check_output(['ps','-eo','pcpu=,comm='],text=True).splitlines():
     cpu,name=line.split(None,1);entries.append({'cpu_percent':float(cpu),'name':pathlib.Path(name).name})
    f.write(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'gpu':gpu,'top_cpu':sorted(entries,key=lambda x:x['cpu_percent'],reverse=True)[:12]})+'\n');f.flush();stop.wait(1)
 except Exception as e:meta['activity_errors'].append(str(e))
save();thread=threading.Thread(target=sample);thread.start()
try:
 for repeat in (1,2,3):
  row={'repeat':repeat,'argv':[str(binpath)],'start':datetime.now(timezone.utc).isoformat()};meta['runs'].append(row);save()
  with (out/f'run-{repeat}.json').open('xb') as stdout,(out/f'run-{repeat}.stderr').open('xb') as stderr:
   child=subprocess.run([str(binpath)],cwd=root,env={'PATH':'/opt/cuda/bin:/usr/bin:/bin','LD_LIBRARY_PATH':'/opt/cuda/lib64'},stdout=stdout,stderr=stderr,timeout=180,check=False)
  row['exit_code']=child.returncode;row['finish']=datetime.now(timezone.utc).isoformat();save()
  if child.returncode:raise RuntimeError(f'run {repeat} failed')
  report=json.loads((out/f'run-{repeat}.json').read_bytes())
  if len(report['cases'])!=12:raise RuntimeError('incomplete shape inventory')
  row['report_sha256']=sha(out/f'run-{repeat}.json');save();print('completed process',repeat,flush=True)
except Exception as e:meta['status']='failed';meta['error']=str(e);raise
finally:
 stop.set();thread.join();save()
if meta['activity_errors']:meta['status']='failed';save();raise RuntimeError('activity sampling failed')
meta['status']='complete';save();print('group complete',flush=True)
