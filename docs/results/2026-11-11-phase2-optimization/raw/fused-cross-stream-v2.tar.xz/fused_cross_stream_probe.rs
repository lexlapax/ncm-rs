//! Isolated real-CUDA diagnostic; no timing or acceptance claim.
use candle_core::{cuda_backend::CudaStorage, op::BackpropOp, Storage, Tensor};
use ncm_backend_cuda::CandleBackend;
use ncm_core::{CodecBackend, WeightBackend};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let b = CandleBackend::cuda(0)?;
    let device = b.device().as_cuda_device()?.clone();
    let main_stream = device.cuda_stream();
    let foreign = main_stream.context().new_stream()?;
    let rows = 8192usize;
    let width = 32usize;
    let out = 16usize;
    let w = b.upload_f32(&vec![1.0; width * out], &[out, width])?;
    let bias = b.upload_f32(&[0.5; 16], &[out])?;
    for _ in 0..8 {
        let mut buf = foreign.clone_htod(&vec![1.0_f32; rows * width])?;
        foreign.memset_zeros(&mut buf)?;
        let storage = CudaStorage::wrap_cuda_slice(buf, device.clone());
        let x = Tensor::from_storage(Storage::Cuda(storage), (rows, width), BackpropOp::none(), false);
        let y = b.project_bias(&x, &w, &bias)?;
        if !b.read_f32(&y)?.iter().all(|&v| v == 0.5) { return Err("foreign-stream output mismatch".into()); }
    }
    println!("{{\"foreign_stream_write_then_fused_read\":true,\"rounds\":8,\"output_elements_per_round\":131072,\"explicit_foreign_stream_sync\":false,\"diagnostic_only\":true}}");
    Ok(())
}
