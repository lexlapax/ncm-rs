from pathlib import Path
p=Path('crates/ncm-model/src/blocks.rs');s=p.read_text();s=s.replace('self.norm("decoder.middle_block.ln_1", x, true, trace)?','self.norm_accelerated("decoder.middle_block.ln_1", x, true, trace)?').replace('self.norm("decoder.middle_block.ln_2", &residual, true, trace)?','self.norm_accelerated("decoder.middle_block.ln_2", &residual, true, trace)?')
old='''        let weight = self.weight(&format!("{name}.weight"))?;
        let y = if name.starts_with("decoder.middle_block.") {
            self.backend.layer_norm_accelerated(x, weight, bias, 1e-6)?
        } else {
            self.backend.layer_norm(x, weight, bias, 1e-6)?
        };'''
assert s.count(old)==1
s=s.replace(old,'''        let y = self
            .backend
            .layer_norm(x, self.weight(&format!("{name}.weight"))?, bias, 1e-6)?;''')
needle='    pub(crate) fn norm(\n';assert s.count(needle)==1
s=s.replace(needle,'''    fn norm_accelerated(&self, name: &str, x: &B::Tensor, bias: bool, trace: &mut impl TraceSink<B>) -> Result<B::Tensor> {
        trace.tensor(&format!("{name}.input"), x)?;
        let bias = if bias { Some(self.weight(&format!("{name}.bias"))?) } else { None };
        let y = self.backend.layer_norm_accelerated(x, self.weight(&format!("{name}.weight"))?, bias, 1e-6)?;
        trace.tensor(&format!("{name}.output"), &y)?;
        Ok(y)
    }
'''+needle);p.write_text(s)
p=Path('crates/ncm-backend-mlx/src/ops.rs');s=p.read_text();old='''    let scores = q
        .matmul(k.swap_axes(-1, -2)?)?
        .multiply(Array::from_f32(1. / (q.shape()[3] as f32).sqrt()))?
        .add(mask)?;
    Ok(ops::softmax_axis(&scores, -1, true)?.matmul(v)?)''';assert s.count(old)==1
s=s.replace(old,'''    let scale = 1. / (q.shape()[3] as f32).sqrt();
    Ok(mlx_rs::fast::scaled_dot_product_attention(q, k, v, scale, mask, None::<&Array>)?)''');p.write_text(s)
