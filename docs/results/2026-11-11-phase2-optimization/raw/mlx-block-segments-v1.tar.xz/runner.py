import hashlib,json,pathlib,subprocess,threading,time
root=pathlib.Path.home()/'projects/lexlapax/ncm-rs'; work=root/'.reference/phase2-mlx-block-segments-v1'; binary=root/'.reference/phase2-mlx-block-segments-target-v1/release/examples/mlx_block_segments'; out=root/'reports/phase2-mlx-block-segments-v1';out.mkdir(exist_ok=False)
meta={'plan':'Three fresh instrumented processes, fixed full codec workload, five warmups and 30 trials per scope. No acceptance claim.','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'commands':[],'thermal_before':subprocess.check_output(['pmset','-g','therm'],text=True)}
stop=threading.Event()
def sample():
 with (out/'activity.jsonl').open('x') as f:
  while not stop.is_set():
   f.write(json.dumps({'time':time.time(),'ps':subprocess.check_output(['ps','-Ao','pcpu=,comm='],text=True)})+'\n');f.flush();stop.wait(2)
t=threading.Thread(target=sample);t.start()
try:
 for i in range(1,4):
  cmd=[str(binary),str(root/'artifacts/canonical/sudoku-easy-qualified'),'tests/fixtures/codec-bench-v1.json',str(out/f'run-{i}.json')];meta['commands'].append({'argv':cmd,'cwd':str(work),'started':time.time()});(out/'plan.json').write_text(json.dumps(meta,indent=2)+'\n');subprocess.run(cmd,cwd=work,env={'PATH':'/usr/bin:/bin'},check=True);meta['commands'][-1]['finished']=time.time()
finally:
 stop.set();t.join();meta['thermal_after']=subprocess.check_output(['pmset','-g','therm'],text=True);(out/'plan.json').write_text(json.dumps(meta,indent=2)+'\n')
