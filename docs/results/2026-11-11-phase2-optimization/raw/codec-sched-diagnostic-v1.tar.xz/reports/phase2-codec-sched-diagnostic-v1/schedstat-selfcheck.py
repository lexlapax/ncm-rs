import json
import subprocess
import sys
import time

child = subprocess.Popen([sys.executable, '-c',
                          'import time; t=time.monotonic()+0.8\nwhile time.monotonic()<t: pass'])
def sched():
    with open('/proc/thread-self/schedstat', encoding='ascii') as f:
        return [int(v) for v in f.read().split()]
before = sched()
end = time.monotonic() + 0.6
while time.monotonic() < end:
    pass
after = sched()
child.wait()
print(json.dumps({'runtime_ns': after[0]-before[0],
                  'runqueue_wait_ns': after[1]-before[1],
                  'timeslices': after[2]-before[2],
                  'purpose': 'verify schedstat increments under owned CPU contention; no GPU access'}))
