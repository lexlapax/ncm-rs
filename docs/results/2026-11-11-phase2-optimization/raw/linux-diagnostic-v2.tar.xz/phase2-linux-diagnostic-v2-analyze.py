"""Reproduce full diagnostic summaries and command/telemetry associations.
Run from repository root after extracting the diagnostic archive into reports/.
No benchmark execution or acceptance adjudication.
"""
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
from zoneinfo import ZoneInfo

sys.path.insert(0, 'tools/bench')
from summarize_codec_load_control import summarize as codec
from summarize_tokenizer_control import summarize as tokenizer
from run_phase2_linux_comparison import order
from phase2_summary import stats
from sample_linux_cpu import activity as cpu_activity

ROOT = Path.cwd()
OUT = Path('reports/phase2-linux-diagnostic-v2')

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def utc(text):
    return datetime.fromisoformat(text)

def dist(values):
    return {'n':len(values),'min':min(values),'median':statistics.median(values),'max':max(values)} if values else {'n':0,'available':False}

def write(path, data):
    Path(path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')

def main():
    env=load(OUT/'environment.json')
    pre=load('reports/phase2-linux-diagnostic-v2-prelaunch.json')
    result=load('reports/phase2-linux-diagnostic-v2-launch-result.json')
    assert result['comparison_returncode']==result['sampler_returncode']==0
    assert env['repeats']==6 and env['workloads']==['codec','gpt2','qwen3']
    assert env['cpu_affinity']==2 and env['observer_cpu']==0 and env['launcher_affinity']==[0]
    assert env['harness_sha256']==pre['identities']['tools/bench/run_phase2_linux_comparison.py']
    assert env['observer_helper_sha256']==pre['identities']['tools/bench/sample_linux_cpu.py']
    assert env['source_heads']['candidate']==pre['head']
    for name in ('venv','tokenizers-venv'):
        assert env[name]==pre['python_environments'][name]
    for runtime, directory in [('previous','.reference/phase2-optimization-baseline-bin'),('candidate','target/release/examples')]:
        for name,h in env['binary_sha256'][runtime].items():
            assert h==pre['identities'][f'{directory}/{name}']
    raw=[json.loads(l) for l in Path('reports/phase2-linux-diagnostic-v2-cpu.jsonl').read_text().splitlines()]
    metadata=raw[0]; completion=raw[-1]; samples=raw[1:-1]
    assert metadata['kind']=='metadata' and metadata['smt_siblings']==[2,3]
    assert metadata['observer_affinity']==[0] and metadata['seconds']==900 and metadata['interval_seconds']==1
    assert completion['kind']=='completion' and completion['status']=='complete'
    assert completion['samples']==len(samples)==901
    assert [s['index'] for s in samples]==list(range(901))
    assert all(s['kind']=='sample' for s in samples)
    assert all(utc(a['utc'])<utc(b['utc']) for a,b in zip(samples,samples[1:]))
    for a,b in zip(samples,samples[1:]):
        assert b['activity_since_previous']==cpu_activity(a['cpu_ticks'],b['cpu_ticks'])
    original_root=next(Path(p).parents[2] for p in pre['identities'] if p.startswith('/') and p.endswith('/tools/reference/codec_bench.py'))
    # nvidia-smi timestamps are host-local, unlike command/sample UTC. The launch
    # host's /etc/localtime was inspected after collection: America/Los_Angeles.
    gpu=[]
    with (OUT/'gpu-telemetry.csv').open() as f:
        for row in csv.DictReader(f,skipinitialspace=True):
            stamp=datetime.strptime(row['timestamp'],'%Y/%m/%d %H:%M:%S.%f').replace(tzinfo=ZoneInfo('America/Los_Angeles')).astimezone(timezone.utc)
            gpu.append({'utc':stamp.isoformat(),'sm_mhz':int(row['clocks.current.sm [MHz]'].split()[0]),'memory_mhz':int(row['clocks.current.memory [MHz]'].split()[0]),'gpu_utilization_percent':int(row['utilization.gpu [%]'].split()[0])})
    expected=[(repeat,profile,runtime) for repeat in range(1,7) for profile in ('codec','gpt2','qwen3') for runtime in order(repeat)]
    assert len(env['commands'])==len(expected)==54
    commands=[]; process_scopes=[]; blocks=[]
    for command,(repeat,profile,runtime) in zip(env['commands'],expected):
        suffix='python' if runtime=='python' else 'rust'
        filename=f'codec-{suffix}-{repeat}.json' if profile=='codec' else f'tokenizer-{profile}-{suffix}-{repeat}.json'
        report_path=OUT/runtime/filename
        argv=command['argv']
        assert command['runtime']==runtime and argv[:3]==['taskset','-c','2']
        assert Path(argv[-1]).name==filename and Path(argv[-1]).parent.name==runtime
        assert str(Path(argv[-1])).endswith(str(report_path))
        expected_cwd=original_root/'.reference/phase2-optimization-baseline' if runtime=='previous' else original_root
        assert command['cwd']==str(expected_cwd)
        bins=original_root/('.reference/phase2-optimization-baseline-bin' if runtime=='previous' else 'target/release/examples')
        if profile=='codec':
            expected_args=([str(original_root/'.reference/venv/bin/python'),'tools/reference/codec_bench.py',str(original_root/'artifacts/canonical/sudoku-easy-qualified'),str(original_root/'.reference/upstream-ncm')] if runtime=='python' else [str(bins/'codec_bench'),str(original_root/'artifacts/canonical/sudoku-easy-qualified')])
            expected_args+=['tests/fixtures/codec-bench-v1.json',str(original_root/report_path)]
        else:
            expected_args=([str(original_root/'.reference/tokenizers-venv/bin/python'),'tools/reference/text_tokenizer_bench.py',str(original_root/'artifacts/upstream/tokenizers-v2'),str(original_root/'.reference/upstream-ncm')] if runtime=='python' else [str(bins/'asset_bench'),str(original_root/'artifacts/canonical/tokenizers-qualified')])
            expected_args+=['tests/fixtures/tokenizers-v1.json',profile,str(original_root/report_path)]
        assert argv==['taskset','-c','2']+expected_args
        assert sha(report_path)==command['report_sha256']
        report=load(report_path)
        assert report['warmups']==5 and report['trials']==30
        if runtime=='python':
            for dest in ('previous','candidate'):
                assert sha(OUT/dest/filename)==sha(report_path)
        for source,h in report['source_sha256'].items():
            alias={'benchmark':'tools/reference/codec_bench.py','inputs_helper':'tools/reference/codec_trace.py','stages':'tools/reference/codec_stages.py'}.get(source,source)
            if runtime=='previous':
                path=str(Path('.reference/phase2-optimization-baseline')/alias)
            else:
                path=str(original_root/alias)
            assert pre['identities'][path]==h,(path,h)
        start=utc(command['started_utc']); end=utc(command['finished_utc'])
        assert start<end and utc(samples[0]['utc'])<=start and end<=utc(samples[-1]['utc'])
        intervals=[(a,b) for a,b in zip(samples,samples[1:]) if utc(a['utc'])<end and utc(b['utc'])>start]
        overlaps=[]
        for a,b in intervals:
            overlaps.append({'sample_index':b['index'],'start_utc':a['utc'],'end_utc':b['utc'],
                'boundary_overlap':utc(a['utc'])<start or utc(b['utc'])>end,
                'activity':{c:b['activity_since_previous'].get(c) for c in ('cpu','cpu0','cpu2','cpu3')},
                'frequency_khz':b['frequency_khz'],'pressure':b['pressure'],
                'system_counters':b['system_counters'],'lateness_seconds':b['lateness_seconds']})
        activity={c:dist([o['activity'][c]['non_idle_non_iowait_percent'] for o in overlaps if o['activity'][c] and o['activity'][c]['available']]) for c in ('cpu','cpu0','cpu2','cpu3')}
        frequencies={c:dist([int(o['frequency_khz'][c]['value']) for o in overlaps if o['frequency_khz'][c]['available']]) for c in ('0','2','3')}
        gpu_inside=[g for g in gpu if start<=utc(g['utc'])<=end]
        commands.append({'repeat':repeat,'profile':profile,'runtime':runtime,**command,'seconds':(end-start).total_seconds(),'cpu_activity_percent':activity,'frequency_khz':frequencies,'sample_lateness_seconds':dist([o['lateness_seconds'] for o in overlaps]),'gpu_samples':gpu_inside,'cpu_intervals':overlaps})
        rows=report['measurements']+[{'scope':'checked_load','trials_ms':report['load_trials_ms']}]
        for row in rows:
            item={'repeat':repeat,'profile':profile,'runtime':runtime,'batch':row.get('batch'),'scope':row['scope'],**stats(row['trials_ms'])}
            if row.get('cuda_stream_spans_ms'):
                item['cuda_event_span']=stats(row['cuda_stream_spans_ms'])
            process_scopes.append(item)
            if profile=='codec' and runtime!='python' and row.get('batch')==1 and row['scope']=='resident_decoder_block':
                blocks.append(item)
    summaries={'codec':codec(OUT,'cuda',include_execution=True),**{p:tokenizer(OUT,p,include_load=True) for p in ('gpt2','qwen3')}}
    limitations=['Diagnostic only; not an acceptance matrix or replacement controls. Existing 72/78 unchanged.',
        'Every process and scope retained; copied Python reports are not independent observations.',
        'Intervals overlapping command boundaries include adjacent/ambient work; no per-request activity attribution.',
        'One-second CPU/frequency/GPU samples cannot isolate sub-millisecond block timing or establish causality.',
        'GPU timestamps converted from US/Pacific (America/Los_Angeles) local time; source CSV retained.',
        'Pressure/counters are system-wide, CPU activity includes the benchmark itself; missing counters retained.',
        'Six cyclic repetitions balance positions but not every predecessor pair.']
    analysis={'schema_version':1,'diagnostic_only':True,'commands_verified':54,'samples_verified':901,'all_commands_bracketed':True,'all_outputs_qualified':True,'gpu_timestamp_zone':'America/Los_Angeles','completion':completion,'sample_lateness_seconds':dist([s['lateness_seconds'] for s in samples]),'commands':commands,'all_process_scopes':process_scopes,'b1_resident_block_processes':blocks,'limitations':limitations,'analyzer_sha256':sha(__file__)}
    write(OUT/'summaries.json',summaries)
    write(OUT/'analysis.json',analysis)
    with (OUT/'commands.tsv').open('w') as f:
        fields=['repeat','profile','runtime','started_utc','finished_utc','seconds','cpu_sample_indices','boundary_sample_indices','cpu2_activity_median_percent','cpu3_activity_max_percent','cpu2_frequency_min_khz','cpu2_frequency_max_khz','max_sample_lateness_seconds','report_sha256']
        writer=csv.DictWriter(f,fieldnames=fields,delimiter='\t');writer.writeheader()
        for c in commands:
            writer.writerow({**{k:c[k] for k in fields if k in c},'cpu_sample_indices':','.join(str(o['sample_index']) for o in c['cpu_intervals']),'boundary_sample_indices':','.join(str(o['sample_index']) for o in c['cpu_intervals'] if o['boundary_overlap']),'cpu2_activity_median_percent':c['cpu_activity_percent']['cpu2']['median'],'cpu3_activity_max_percent':c['cpu_activity_percent']['cpu3']['max'],'cpu2_frequency_min_khz':c['frequency_khz']['2']['min'],'cpu2_frequency_max_khz':c['frequency_khz']['2']['max'],'max_sample_lateness_seconds':c['sample_lateness_seconds']['max']})
    print('Verified 54 commands, all report identities/outputs, 901 samples, complete coverage; no acceptance change.')

if __name__=='__main__':
    main()
