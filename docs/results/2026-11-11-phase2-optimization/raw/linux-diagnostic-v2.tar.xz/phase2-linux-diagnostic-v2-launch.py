"""Single-use launch-time identity recheck and fixed diagnostic; no retries."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT/'tools/bench'))
from run_phase2_linux_comparison import validate_observer

def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def capture(argv, cwd=ROOT):
    return subprocess.check_output(argv, cwd=cwd, text=True).strip()

def save(path, data):
    with Path(path).open('x') as f:
        json.dump(data, f, indent=2); f.write('\n')

out = Path('reports/phase2-linux-diagnostic-v2')
cpu = Path('reports/phase2-linux-diagnostic-v2-cpu.jsonl')
manifest_path = Path('reports/phase2-linux-diagnostic-v2-prelaunch.json')
assert not out.exists() and not cpu.exists() and not manifest_path.exists()
validate_observer(2, 0)
base = Path('.reference/phase2-optimization-baseline')
controls = Path('reports/phase2-optimization-controls-threeway-v1')
env = json.loads((controls/'environment.json').read_text())
assert digest(controls/'environment.json') == '77f773708ec4d98272d06353819b7ef2390432076d3bd22af6d923fa3eb1a82d'
head = capture(['git','rev-parse','HEAD'])
assert head == capture(['git','rev-parse','origin/main']) == 'fa040ed34a44a577bc4e6e297c944393cdf6cfda'
assert capture(['git','status','--porcelain'], base) == ''
assert capture(['git','rev-parse','HEAD'], base) == '3307dff82a08f7251b64de0866a01d131528b74f'
assert capture(['git','diff','d44beaa','HEAD','--','crates/*/src','Cargo.lock']) == ''
assert capture(['git','diff','HEAD']) == ''
assert not any(os.environ.get(k) for k in ('CUDA_INJECTION64_PATH','NVTX_INJECTION64_PATH','LD_PRELOAD'))
identities = {}
def check(path, expected):
    actual = digest(path)
    assert actual == expected, str(path)
    identities[str(path)] = actual

for runtime, directory in [('previous',Path('.reference/phase2-optimization-baseline-bin')),('candidate',Path('target/release/examples'))]:
    for name, expected in env['binary_sha256'][runtime].items():
        check(directory/name, expected)
for runtime in ('previous','candidate','python'):
    source_root = base if runtime == 'previous' else ROOT
    for profile in ('codec','gpt2','qwen3'):
        filename = f'codec-{ "python" if runtime == "python" else "rust"}-1.json' if profile == 'codec' else f'tokenizer-{profile}-{ "python" if runtime == "python" else "rust"}-1.json'
        report = json.loads((controls/runtime/filename).read_text())
        aliases = {'benchmark':'tools/reference/codec_bench.py','inputs_helper':'tools/reference/codec_trace.py','stages':'tools/reference/codec_stages.py'}
        for name, expected in report['source_sha256'].items():
            check(source_root/aliases.get(name, name), expected)
        fixture = 'tests/fixtures/codec-bench-v1.json' if profile == 'codec' else 'tests/fixtures/tokenizers-v1.json'
        check(source_root/fixture, report.get('workload_sha256',report.get('fixture_sha256')))
        artifact = 'artifacts/canonical/sudoku-easy-qualified/manifest.json' if profile == 'codec' else f'artifacts/canonical/tokenizers-qualified/{profile}/manifest.json'
        check(artifact, report['manifest_sha256'])
payload_path = Path('reports/phase2-linux-diagnostic-v2-payload-preflight.json')
check(payload_path,'28902ca75deb023342703f56feb7425589d5c52d08cdac868e496b07c007354e')
payload = json.loads(payload_path.read_text())
for path, expected in payload['anchors_sha256'].items():
    check(path, expected)
for file in payload['files']:
    assert Path(file['path']).stat().st_size == file['bytes']
    check(file['path'],file['sha256'])
assert capture(['git','rev-parse','HEAD'],Path('.reference/upstream-ncm')) == payload['upstream']['head']
assert capture(['git','status','--porcelain'],Path('.reference/upstream-ncm')) == ''
python_envs = {}
for venv in ('venv','tokenizers-venv'):
    exe = str(ROOT/f'.reference/{venv}/bin/python')
    actual = {'python':capture([exe,'--version']), 'packages':capture([exe,'-m','pip','freeze'])}
    assert actual == env[venv], venv
    python_envs[venv] = actual
sampler = ['python','tools/bench/sample_linux_cpu.py',str(cpu),'--cpu','2','--observer-cpu','0','--seconds','900','--interval','1']
comparison = ['python','tools/bench/run_phase2_linux_comparison.py',str(base),'.reference/phase2-optimization-baseline-bin',str(out),'--cpu','2','--observer-cpu','0','--repeats','6','--workloads','codec','gpt2','qwen3']
for path in ('docs/results/2026-11-11-phase2-optimization/linux-diagnostic-protocol-v2.md','tools/bench/run_phase2_linux_comparison.py','tools/bench/sample_linux_cpu.py',__file__):
    identities[str(path)] = digest(path)
manifest = {'utc':datetime.now(timezone.utc).isoformat(),'user_confirmation':'yes. go','diagnostic_only':True,'acceptance_unchanged':'72/78','head':head,'status':capture(['git','status','--short']),'diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'])).hexdigest(),'identities':identities,'python_environments':python_envs,'allowed_affinity':sorted(os.sched_getaffinity(0)),'workload_siblings':Path('/sys/devices/system/cpu/cpu2/topology/thread_siblings_list').read_text().strip(),'observer_siblings':Path('/sys/devices/system/cpu/cpu0/topology/thread_siblings_list').read_text().strip(),'commands':[sampler,comparison],'errors':[]}
save(manifest_path,manifest)
print('Preflight passed; manifest saved; starting fixed capture',flush=True)
with Path('reports/phase2-linux-diagnostic-v2-sampler.log').open('x') as sl, Path('reports/phase2-linux-diagnostic-v2-comparison.log').open('x') as cl:
    sample = subprocess.Popen(sampler,stdout=sl,stderr=subprocess.STDOUT)
    try:
        deadline = time.monotonic()+15
        while True:
            if sample.poll() is not None:
                raise RuntimeError('sampler exited before comparison')
            if cpu.exists():
                lines = cpu.read_text().splitlines()
                if len(lines)>=2:
                    first = [json.loads(line) for line in lines[:2]]
                    assert first[0]['kind']=='metadata' and first[0]['observer_affinity']==[0]
                    assert first[1]['kind']=='sample'
                    break
            if time.monotonic()>deadline:
                raise RuntimeError('no first sample within startup bound')
            time.sleep(.1)
        result = subprocess.run(comparison,stdout=cl,stderr=subprocess.STDOUT)
        print('Comparator exited:',result.returncode,'; waiting for full sampler',flush=True)
    finally:
        sample_rc = sample.wait()
    save('reports/phase2-linux-diagnostic-v2-launch-result.json',{'comparison_returncode':result.returncode,'sampler_returncode':sample_rc,'finished_utc':datetime.now(timezone.utc).isoformat()})
    assert result.returncode == sample_rc == 0
print('Fixed collection ended; analysis not yet performed',flush=True)
