import runpy,json,statistics
z=runpy.run_path('analyze-private.py'); ints=z['intervals'];gpu=z['gpu'];values=z['vals']; f=z['overlap'];out=[]
for i,v in enumerate(values):
 a,b=(ints[78+i][k] for k in ('start','end')); ws=[(x[0],x[1]) for x in gpu if x[2].startswith('WindowServer (')]; other=[(x[0],x[1]) for x in gpu if not x[2].startswith(('WindowServer (','mlx_block_segments ('))];w,n=f(ws,a,b);o,m=f(other,a,b);out.append({'trial':i,'wall_ms':v,'windowserver_union_ms':w,'windowserver_records':n,'other_union_ms':o,'other_records':m})
print('SUMMARY '+json.dumps({'median_ms':statistics.median(values),'trials':out},sort_keys=True))
