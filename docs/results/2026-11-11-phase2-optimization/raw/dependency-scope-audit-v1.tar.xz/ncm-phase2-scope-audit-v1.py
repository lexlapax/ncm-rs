import hashlib,json,pathlib,subprocess,sys,tarfile,tomllib
root=pathlib.Path(sys.argv[1]).resolve(); archive=pathlib.Path(sys.argv[2]).resolve(); output=pathlib.Path(sys.argv[3])
expected_archive='b238e22d44a15349529690fb07bd645cf58149a1b1e44d6cb5bd1641ff1a6223'
expected={'src/models/bpe/model.rs':'582e8fe','src/normalizers/bert.rs':'4ab4d3a','src/pre_tokenizers/byte_level.rs':'211df63'}
h=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
if output.exists():raise ValueError('output exists')
if git('status','--porcelain','--untracked-files=no').strip():raise ValueError('tracked worktree differs')
if h(archive.read_bytes())!=expected_archive:raise ValueError('archive checksum differs')
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers(); files={m.name.removeprefix('tokenizers-0.22.2/'):t.extractfile(m).read() for m in members if m.isfile()}
 if any(not(m.isfile() or m.isdir()) for m in members) or any(not m.name.startswith('tokenizers-0.22.2/') for m in members):raise ValueError('unexpected archive member')
vend=root/'vendor/tokenizers-0.22.2'; actual={p.relative_to(vend).as_posix():p.read_bytes() for p in vend.rglob('*') if p.is_file()}
if files.keys()!=actual.keys():raise ValueError('vendor file inventory differs')
changed={p:{'upstream_sha256':h(files[p]),'vendored_sha256':h(actual[p])} for p in sorted(files) if files[p]!=actual[p]}
if set(changed)!=set(expected):raise ValueError('unexpected vendored changes')
for p,commit in expected.items():
 if git('show',f'{commit}:vendor/tokenizers-0.22.2/{p}')!=actual[p]:raise ValueError('integrated version differs from reviewed commit: '+p)
old=tomllib.loads(git('show','3307dff:Cargo.lock').decode()); new=tomllib.loads((root/'Cargo.lock').read_text())
key=lambda x:(x['name'],x['version']); a={key(x):x for x in old['package']};b={key(x):x for x in new['package']}
if len(a)!=len(old['package']) or len(b)!=len(new['package']) or a.keys()!=b.keys():raise ValueError('package inventory differs')
previous=dict(a[('tokenizers','0.22.2')]); previous.pop('source');checksum=previous.pop('checksum')
if checksum!=expected_archive or previous!=b[('tokenizers','0.22.2')]:raise ValueError('tokenizers lock mismatch')
if any(a[k]!=b[k] for k in a if k!=('tokenizers','0.22.2')):raise ValueError('other package changed')
pins=['upstream.toml','tools/reference/tokenizer-sources.lock.json','tools/reference/tokenizers-v1.lock.json']
for p in pins:
 if git('show',f'3307dff:{p}')!=(root/p).read_bytes():raise ValueError('pin changed: '+p)
if git('diff','--name-only','3307dff','HEAD','--','tests/fixtures').strip():raise ValueError('fixture changed')
report={'schema_version':1,'head':git('rev-parse','HEAD').decode().strip(),'baseline':git('rev-parse','3307dff').decode().strip(),'archive_sha256':expected_archive,'vendored_regular_files':len(files),'changed_vendored_files':changed,'integrated_commit_by_file':expected,'package_count':len(a),'only_lock_change':'tokenizers 0.22.2 source/checksum removed for approved local vendoring','pin_files_unchanged':pins,'tracked_fixture_diff_empty':True,'limitations':['Compares tracked package/source scope and selected pins; not a complete semantic or security audit.','Requires the checksum-pinned crate archive and git history; does not establish GPU performance acceptance.']}
output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
