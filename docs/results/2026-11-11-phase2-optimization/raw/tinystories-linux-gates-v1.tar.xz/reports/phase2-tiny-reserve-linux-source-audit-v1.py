"""Verify retained native and Python report inventories against clean exports.

Run from the repository root with the gate archive extracted there; pass
clean git-archive directories for 3307dff and fb6c75e in that order.
Python comparator reports appear in three directories but are shared copies.
"""
import collections
import hashlib
import json
from pathlib import Path
import sys

if len(sys.argv) != 3:
    raise SystemExit('usage: python3 blocknorm-source-audit-v1.py BASELINE LINUX')
roots = dict(zip(('baseline', 'linux'), map(Path, sys.argv[1:])))
archives = (
    ('linux-matrix', Path('reports/phase2-tiny-reserve-linux-matrix-v1'), 'linux', 30, 45),
    ('linux-controls', Path('reports/phase2-tiny-reserve-linux-control-v1'), 'linux', 90, 135),
)
aliases = {'benchmark': 'tools/reference/codec_bench.py',
           'inputs_helper': 'tools/reference/codec_trace.py',
           'stages': 'tools/reference/codec_stages.py'}
expected_heads = {'baseline': '3307dff82a08f7251b64de0866a01d131528b74f',
                  'linux': 'fb6c75ee1cfe267a7ed3c5199796688d8c102e1d'}
counts = collections.Counter()
failures = []
for label, directory, candidate, native_count, python_count in archives:
    env = json.loads((directory / 'environment.json').read_bytes())
    if env['source_heads'] != {'previous': expected_heads['baseline'],
                               'candidate': expected_heads[candidate]}:
        failures.append((label, 'source_heads'))
    for runtime in ('previous', 'candidate', 'python'):
        for path in sorted((directory / runtime).glob('*.json')):
            report = json.loads(path.read_bytes())
            inventory = report.get('source_sha256')
            if not isinstance(inventory, dict) or not inventory:
                failures.append((str(path), 'missing inventory'))
                continue
            is_python = '-python-' in path.name
            root = roots[candidate if is_python or runtime != 'previous' else 'baseline']
            for name, expected in inventory.items():
                source = root / aliases.get(name, name)
                if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != expected:
                    failures.append((str(path), name))
            counts[(label, 'python' if is_python else 'native')] += 1
    for kind, expected in (('native', native_count), ('python', python_count)):
        if counts[(label, kind)] != expected:
            failures.append((label, f'{kind} count'))
    for path in (directory / 'python').glob('*-python-*.json'):
        digest = hashlib.sha256(path.read_bytes()).digest()
        for runtime in ('previous', 'candidate'):
            copy = directory / runtime / path.name
            if not copy.is_file() or hashlib.sha256(copy.read_bytes()).digest() != digest:
                failures.append((str(copy), 'shared Python copy mismatch'))
print(json.dumps({'counts': {f'{a}/{b}': n for (a, b), n in sorted(counts.items())},
                  'mismatches': failures, 'python_reports_are_shared_copies': True}, indent=2))
if failures:
    raise SystemExit(1)
