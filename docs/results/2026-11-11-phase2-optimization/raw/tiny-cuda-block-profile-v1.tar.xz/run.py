import hashlib,json,os,pathlib,resource,subprocess,time
p=pathlib.Path('reports/phase2-tiny-cuda-block-profile-v1');plan=json.load(open(p/'plan.json'));trace=p/'capture.txt';env=os.environ.copy();env['CUDA_INJECTION64_PATH']=str(pathlib.Path('.reference/phase2-cupti/libcupti_trace_injection.so').resolve());cmd=['taskset','-c','2','target/release/examples/codec_bench','artifacts/canonical/sudoku-easy-qualified','tests/fixtures/codec-bench-v1.json',str(p/'result.json'),'--profile-block4'];start=time.monotonic()
def limit(): resource.setrlimit(resource.RLIMIT_FSIZE,(plan['max_capture_bytes'],plan['max_capture_bytes']))
with trace.open('xb') as out:
 try:r=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=plan['timeout_seconds'],preexec_fn=limit);rc=r.returncode
 except subprocess.TimeoutExpired:rc='timeout'
result={'returncode':rc,'elapsed_seconds':time.monotonic()-start,'capture_bytes':trace.stat().st_size,'capture_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'diagnostic_only':True};(p/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if rc==0 else 1)
