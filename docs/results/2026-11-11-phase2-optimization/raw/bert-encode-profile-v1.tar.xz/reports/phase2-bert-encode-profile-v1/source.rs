use ncm_tokenizers::TextTokenizer;
use serde_json::Value;
use std::{error::Error, fs, hint::black_box, time::Instant};
fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 4 { return Err("usage: profile BERT_ASSET FIXTURE ROUNDS".into()); }
    let tokenizer = TextTokenizer::load(&args[1])?;
    let fixture: Value = serde_json::from_slice(&fs::read(&args[2])?)?;
    let cases = fixture["profiles"]["bert"]["cases"].as_array().ok_or("missing cases")?;
    if cases.len() != 89 { return Err("unexpected case count".into()); }
    let rounds: usize = args[3].parse()?;
    let start = Instant::now();
    let mut ids = 0usize;
    for _ in 0..rounds {
        for case in cases {
            let text = case["text"].as_str().ok_or("missing text")?;
            ids += black_box(tokenizer.encode(black_box(text))?).len();
        }
    }
    println!("rounds={rounds} total_ids={ids} elapsed_ms={}", start.elapsed().as_secs_f64()*1000.);
    Ok(())
}
