//! Synthetic resident-block diagnostic; no prior encode/decode/reconstruction.
#[path = "../../../tests/support/host_memory.rs"]
mod host_memory;
use mlx_rs::memory;
use ncm_backend_mlx::MlxBackend;
use ncm_core::{CodecBackend, WeightBackend};
use ncm_io::{Artifact, sha256};
use ncm_model::Codec;
use serde_json::json;
use std::{error::Error, fs, path::Path, time::Instant};
type Result<T> = std::result::Result<T, Box<dyn Error>>;
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 3 || cfg!(debug_assertions) || Path::new(&args[2]).exists() {
        return Err("usage (release): mlx_block_isolated ARTIFACT NEW_REPORT".into());
    }
    let b = MlxBackend::gpu()?;
    let artifact = Artifact::load(&args[1])?;
    let model = Codec::from_artifact(b.clone(), &artifact)?;
    b.evaluate(&model.weights().values().cloned().collect::<Vec<_>>())?;
    let mut rows = Vec::new();
    for batch in [1_usize, 2, 4] {
        let values: Vec<f32> = (0..batch * 89 * 256)
            .map(|i| ((i * 73 % 509) as f32 - 254.) / 37.)
            .collect();
        let x = b.upload_f32(&values, &[batch, 89, 256])?;
        b.evaluate(std::slice::from_ref(&x))?;
        memory::reset_peak_memory()?;
        let mut times = Vec::new();
        let mut hashes = Vec::new();
        for i in 0..36 {
            let start = Instant::now();
            let output = model.decoder_block(&x)?;
            b.evaluate(std::slice::from_ref(&output))?;
            let ms = start.elapsed().as_secs_f64() * 1000.;
            if i == 0 || i == 35 {
                let result = b.read_f32(&output)?;
                hashes.push(sha256(
                    &result
                        .iter()
                        .flat_map(|v| v.to_le_bytes())
                        .collect::<Vec<_>>(),
                ));
            }
            if i >= 6 {
                times.push(ms);
            }
        }
        if hashes[0] != hashes[1] {
            return Err("nonrepeatable block output".into());
        }
        rows.push(json!({"batch":batch,"trials_ms":times,"float_sha256":hashes[0],
            "mlx_peak":memory::peak_memory()?,"mlx_active":memory::active_memory()?,"mlx_cache":memory::cache_memory()?,"host":host_memory::host()?}));
    }
    let paths = [
        "crates/ncm-backend-mlx/examples/mlx_block_isolated.rs",
        "crates/ncm-backend-mlx/src/codec.rs",
        "crates/ncm-backend-mlx/src/ops.rs",
        "crates/ncm-model/src/blocks.rs",
        "Cargo.lock",
    ];
    let sources: std::collections::BTreeMap<_, _> = paths
        .into_iter()
        .map(|p| Ok((p, sha256(&fs::read(p)?))))
        .collect::<Result<_>>()?;
    let report = json!({"schema_version":1,"scope":"synthetic resident decoder block, no prior codec execution, not acceptance","manifest_sha256":sha256(&fs::read(Path::new(&args[1]).join("manifest.json"))?),"source_sha256":sources,"warmups":5,"trials":30,"rows":rows});
    serde_json::to_writer_pretty(
        fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&args[2])?,
        &report,
    )?;
    Ok(())
}
