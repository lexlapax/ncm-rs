use ncm_backend_mlx::MlxBackend;
use ncm_core::CodecBackend;
use ncm_io::{Artifact, sha256};
use ncm_model::Codec;
use serde_json::json;
use std::{error::Error, fs, io::Write, path::Path};
fn main() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 3 || cfg!(debug_assertions) {
        return Err("usage: mlx_strides ARTIFACT".into());
    }
    let b = MlxBackend::gpu()?;
    let artifact = Artifact::load(&args[1])?;
    let model = Codec::from_artifact(b.clone(), &artifact)?;
    b.evaluate(&model.weights().values().cloned().collect::<Vec<_>>())?;
    let mut rows = Vec::new();
    for batch in [1, 2, 4] {
        let mut tokens = Vec::new();
        for i in 0..batch {
            for row in 0..9 {
                if row > 0 {
                    tokens.push(10);
                }
                for col in 0..9 {
                    tokens.push(((row * 3 + row / 3 + col + i % 2) % 9 + 1) as u32);
                }
            }
        }
        let encoded = model.encode(&tokens, batch)?;
        b.evaluate(&encoded.snapshots)?;
        for (level, value) in encoded.snapshots.iter().enumerate() {
            let values = b.read_f32(value)?;
            let bytes: Vec<u8> = values.iter().flat_map(|v| v.to_le_bytes()).collect();
            if level == 11 {
                let file = Path::new(&args[2]).join(format!("batch-{batch}.bin"));
                fs::OpenOptions::new()
                    .write(true)
                    .create_new(true)
                    .open(file)?
                    .write_all(&bytes)?;
            }
            rows.push(json!({"batch":batch,"level":level,"shape":b.shape(value),"strides":value.diagnostic_strides(),"float_sha256":sha256(&bytes)}));
        }
    }
    println!(
        "{}",
        serde_json::to_string(
            &json!({"schema_version":1,"scope":"diagnostic snapshot layout after evaluation; no timing","rows":rows})
        )?
    );
    Ok(())
}
