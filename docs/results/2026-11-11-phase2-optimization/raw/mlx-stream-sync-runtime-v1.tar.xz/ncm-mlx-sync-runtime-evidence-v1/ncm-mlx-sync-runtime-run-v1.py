"""Counterbalanced full-codec and retained-root MLX diagnostic; not acceptance."""
import hashlib,json,os,subprocess,threading
from pathlib import Path
from datetime import datetime,timezone
root=Path.home()/'projects/lexlapax/ncm-rs';os.chdir(root)
out=root/'reports/phase2-mlx-sync-runtime-diagnostic-v1';artifact=root/'artifacts/canonical/sudoku-easy-qualified';fixture=root/'tests/fixtures/codec-bench-v1.json'
work={'current':root,'sync':root/'.reference/phase2-mlx-sync-runtime-v1'}
bins={'current':{'codec':root/'target/release/examples/mlx_codec_bench','memory':root/'.reference/phase2-mlx-live-candidate-target-v1/release/examples/mlx_live_memory_probe'},'sync':{'codec':root/'.reference/phase2-mlx-sync-runtime-target-v1/release/examples/mlx_codec_bench','memory':root/'.reference/phase2-mlx-sync-runtime-target-v1/release/examples/mlx_live_memory_probe'}}
expected={'current':{'codec':'6bb8929ce0704a659423e8ef7082dfd4a4388bb309339924e0d943f7cd6ef46b','memory':'a9f021476418396e455805261b3dce86009eefc1be2084885721a663c97c21e3'},'sync':{'codec':'de9727c5d1b9612be31361504db0ef9e553e6353b32d111eeeb85dd61a0ac91f','memory':'28182ea2dc0f167901ffaf0889b444afc332ce317098c84741489de75c9cfe15'}}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if {r:{k:sha(p) for k,p in x.items()} for r,x in bins.items()}!=expected:raise ValueError('binary identity differs')
codec='crates/ncm-backend-mlx/src/codec.rs'
if {r:sha(x/codec) for r,x in work.items()}!={'current':'2283893a503fbf18de4a92024971cd4cac010a2032acde1f752c14fe39bdea4f','sync':'b79c8f03a7046cab89d726f41bd96c5bfc5e2fc66dcccd2c62a32f599ee5002e'}:raise ValueError('source identity differs')
if any(os.environ.get(k) for k in ('DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','MTL_CAPTURE_ENABLED')):raise ValueError('instrumented environment')
out.mkdir(mode=0o700);now=lambda:datetime.now(timezone.utc).isoformat()
meta={'status':'running','started':now(),'manifest_sha256':sha(artifact/'manifest.json'),'fixture_sha256':sha(fixture),'binary_sha256':expected,'codec_source_sha256':{r:sha(x/codec) for r,x in work.items()},'commands':[],'thermal_before':subprocess.check_output(['/usr/bin/pmset','-g','therm'],text=True)}
stop=threading.Event()
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
def sample():
 try:
  with (out/'activity.jsonl').open('x') as f:
   while not stop.is_set():
    entries=[]
    for line in subprocess.check_output(['/bin/ps','-Ao','pcpu=,comm='],text=True).splitlines():
     cpu,name=line.split(None,1);entries.append({'cpu_percent':float(cpu),'name':Path(name).name})
    f.write(json.dumps({'utc':now(),'top_cpu':sorted(entries,key=lambda x:x['cpu_percent'],reverse=True)[:12]})+'\n');f.flush();stop.wait(2)
 except Exception as e:meta['activity_error']=str(e)
save();thread=threading.Thread(target=sample);thread.start()
try:
 for kind in ('codec','memory'):
  for repeat in range(1,4):
   for role in (('current','sync') if repeat%2 else ('sync','current')):
    report=out/f'{kind}-{role}-{repeat}.json';argv=[str(bins[role][kind]),str(artifact)]+([str(fixture)] if kind=='codec' else [])+[str(report)];entry={'kind':kind,'role':role,'repeat':repeat,'argv':argv,'cwd':str(work[role]),'start':now()};meta['commands'].append(entry);save()
    with (out/f'{kind}-{role}-{repeat}.stdout').open('xb') as stdout,(out/f'{kind}-{role}-{repeat}.stderr').open('xb') as stderr:
     child=subprocess.run(argv,cwd=work[role],env={'PATH':'/usr/bin:/bin','HF_HUB_OFFLINE':'1','TOKENIZERS_PARALLELISM':'false'},stdout=stdout,stderr=stderr,timeout=180,check=False)
    entry['returncode']=child.returncode;entry['finish']=now();save()
    if child.returncode:raise RuntimeError(f'{kind} {role} {repeat} failed')
    obj=json.loads(report.read_bytes());entry['report_sha256']=sha(report);save();print(kind,role,repeat,'complete',flush=True)
except Exception as e:meta['status']='failed';meta['error']=str(e);raise
finally:stop.set();thread.join();meta['thermal_after']=subprocess.check_output(['/usr/bin/pmset','-g','therm'],text=True);save()
if 'activity_error' in meta:meta['status']='failed';save();raise RuntimeError(meta['activity_error'])
meta['status']='complete';meta['finished']=now();save();print('group complete',flush=True)
