"""Fresh Metal capture with before/after local executable and source identities."""
import hashlib,json,os,subprocess
from pathlib import Path
from datetime import datetime,timezone
root=Path.home()/'projects/lexlapax/ncm-rs';os.chdir(root)
out=Path('/tmp/ncm-mlx-bound-trace-evidence-v2');trace=root/'reports/phase2-codec/mlx-bound-provenance-v2';oracle=root/'reports/phase2-oracle/v1/sudoku-cuda';artifact=root/'artifacts/canonical/sudoku-easy-qualified';binpath=root/'target/release/examples/mlx_codec_trace'
paths={'binary':binpath,'codec':root/'crates/ncm-backend-mlx/src/codec.rs','ops':root/'crates/ncm-backend-mlx/src/ops.rs','blocks':root/'crates/ncm-model/src/blocks.rs','core':root/'crates/ncm-core/src/lib.rs','manifest':artifact/'manifest.json','mlx':root/'.reference/mlx-native/lib/libmlx.dylib','metal':root/'.reference/mlx-native/lib/mlx.metallib'}
expected={'binary':'8f67496922c7c10376293b53532fd514a7d2f337e075d653c1c070e69ef31381','codec':'2283893a503fbf18de4a92024971cd4cac010a2032acde1f752c14fe39bdea4f','ops':'43339b8f874de5192850304d7ef96b87171bc3d1ba5d60f60883c2b45d6ab91e','blocks':'efbc829cfb79d45d027f0013ee81fa24be52f74c5384ad254a9deb7fe30ed7b0','core':'d0da4ab23c149973ba9e02643f34c3832461312c76c11444675766921d95132b','manifest':'ad6a99ad7d5ccc069e0fedf26a85f755e06cd76590463e1e04e17363e35d9832','mlx':'d24c7a9b9d55a76bfd3bbcd1d042251a185cbadcb6340c3244a6ffa3dcb7c7e8','metal':'dc59d1cceb1a5c7e578232e6e41e28e2c73c9463ac6dbc3886c3ee17ffc270ed'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''):h.update(x)
 return h.hexdigest()
def ids():return {k:sha(v) for k,v in paths.items()}
if trace.exists() or out.exists():raise ValueError('destination exists')
if ids()!=expected:raise ValueError('initial identity differs')
if subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip():raise ValueError('main checkout not clean')
if subprocess.check_output(['git','diff','f155794','HEAD','--','crates/ncm-backend-mlx','crates/ncm-model','crates/ncm-core','crates/ncm-io','Cargo.lock','tests/fixtures'],cwd=root):raise ValueError('model source differs from candidate')
if any(os.environ.get(k) for k in ('DYLD_INSERT_LIBRARIES','DYLD_LIBRARY_PATH','MTL_CAPTURE_ENABLED')):raise ValueError('instrumented environment')
out.mkdir(mode=0o700);now=lambda:datetime.now(timezone.utc).isoformat()
argv=[str(binpath),str(artifact),str(oracle),str(trace)];meta={'status':'running','scope':'bound Metal trace capture; not performance or memory acceptance','started':now(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'identities_before':ids(),'argv':argv}
def save():(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
save()
try:
 with (out/'capture.stdout').open('xb') as a,(out/'capture.stderr').open('xb') as b:
  child=subprocess.run(argv,cwd=root,env={'PATH':'/usr/bin:/bin','HF_HUB_OFFLINE':'1','TOKENIZERS_PARALLELISM':'false'},stdout=a,stderr=b,timeout=180,check=False)
 meta['returncode']=child.returncode
 if child.returncode:raise RuntimeError('capture failed')
 meta['identities_after']=ids()
 if meta['identities_after']!=expected:raise ValueError('identity changed')
 report=json.loads((trace/'report.json').read_bytes());meta['trace_sha256']=sha(trace/'traces.safetensors');meta['candidate_report_sha256']=sha(trace/'report.json')
 if report['trace_sha256']!=meta['trace_sha256'] or report['trace_count']!=642:raise ValueError('capture incomplete')
 meta['status']='complete'
except Exception as e:meta['status']='failed';meta['error']=str(e);raise
finally:meta['finished']=now();save()
print('bound Metal capture complete',flush=True)
