import xml.etree.ElementTree as ET,collections,re,json,statistics

def parse(path):
 root=ET.parse(path).getroot(); ids={e.get('id'):e for e in root.iter() if e.get('id')};node=root.find('node')
 def get(e):
  while e.get('ref'): e=ids[e.get('ref')]
  return e
 return node.findall('row'),get
rows,get=parse('markers.xml'); intervals={};
for row in rows:
 cols=list(row);time=int(get(cols[0]).text);kind=get(cols[3]).text;name=get(cols[6]).text;meta=get(cols[11]).get('fmt');match=re.fullmatch(r'batch=(\d+) sequence=(\d+)',meta or '');assert match,(name,meta);batch,seq=map(int,match.groups()); d=intervals.setdefault(seq,{'batch':batch});assert d['batch']==batch;key={'Begin':'start','Event':'graph','End':'end'}[kind];assert key not in d;d[key]=time
assert len(intervals)==108
for i in range(108):
 d=intervals[i];assert d['batch']==([1,2,4][i//36]) and d['start']<d['graph']<d['end'];assert i==107 or d['end']<intervals[i+1]['start']
report=json.load(open('report.json'));m=next(z for z in report['measurements'] if z['batch']==4 and z['scope']=='resident_decoder_block'); trials=m['trials_ms']; seg=m['block_graph_eval_ms']; assert len(trials)==len(seg)==30
for i in range(30):
 d=intervals[78+i]; marker=(d['end']-d['start'])/1e6; assert abs(marker-(seg[i][0]+seg[i][1]))<0.1,(i,marker,seg[i]); assert abs(marker-trials[i])<0.15,(i,marker,trials[i])
rows,get=parse('gpu-intervals.xml'); gpu=[]
for row in rows:
 c=list(row);s=int(get(c[0]).text);duration=int(get(c[1]).text);gpu.append((s,s+duration))
def union_ns(ranges):
 out=0;end=-1
 for a,b in sorted(ranges):
  if a>end:out+=b-a;end=b
  elif b>end:out+=b-end;end=b
 return out
med=statistics.median(trials); slow=[i for i,v in enumerate(trials) if v>1.2*med]; normal=sorted(range(30),key=lambda i:abs(trials[i]-med))[:5]
print('markers',len(intervals),'events',len(rows),'batch4 median',med,'slow indices',slow,'median-close indices',normal)
for i in slow+normal:
 d=intervals[78+i];a=d['start'];b=d['end'];overlap=[(max(s,a),min(e,b)) for s,e in gpu if s<b and e>a];print('trial',i,'wall_ms',round(trials[i],6),'marker_ms',round((b-a)/1e6,6),'graph_ms',round(seg[i][0],6),'eval_ms',round(seg[i][1],6),'gpu_overlap_union_ms',round(union_ns(overlap)/1e6,6),'gpu_intervals',len(overlap))
rows,get=parse('gpu-intervals.xml')
for i in slow+normal[:2]:
 d=intervals[78+i];a=d['start'];b=d['end']; print('DETAIL trial',i)
 for row in rows:
  c=list(row);s=int(get(c[0]).text);dur=int(get(c[1]).text)
  if s<b and s+dur>a:
   print('offset_start_ms',round((s-a)/1e6,6),'duration_ms',round(dur/1e6,6),'start_latency_ms',round(int(get(c[4]).text)/1e6,6),'channel',get(c[2]).get('fmt'),'label',get(c[6]).get('fmt'))
