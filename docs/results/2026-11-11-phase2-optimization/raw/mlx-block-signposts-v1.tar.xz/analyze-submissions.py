import runpy
x=runpy.run_path('analyze.py'); parse=x['parse']; intervals=x['intervals']
for i in [11,9,21]:
 d=intervals[78+i];a=d['start'];b=d['end'];print('TRIAL',i)
 for file in ('submissions.xml','driver.xml'):
  rows,get=parse(file); events=[]
  for row in rows:
   c=list(row);s=int(get(c[0]).text);duration=int(get(c[1]).text)
   if s<b and s+duration>a:
    events.append((round((s-a)/1e6,4),round(duration/1e6,4),get(c[2]).get('fmt'),get(c[3]).get('fmt')))
  print(file,'matches',len(events),'events',events[:12])
grows,gg=parse('gpu-intervals.xml');srows,sg=parse('submissions.xml')
for i in [11,9,21]:
 d=intervals[78+i];a=d['start'];b=d['end'];
 for row in grows:
  c=list(row);s=int(gg(c[0]).text);dur=int(gg(c[1]).text)
  if s<b and s+dur>a:
   ident=gg(c[15]).text; matches=[]
   for sr in srows:
    sc=list(sr)
    if sg(sc[14]).text==ident:
     ss=int(sg(sc[0]).text);matches.append((round((ss-a)/1e6,6),round(int(sg(sc[1]).text)/1e6,6)))
   print('ID MATCH trial',i,'gpu_cmdbuffer',ident,'submissions',matches)
