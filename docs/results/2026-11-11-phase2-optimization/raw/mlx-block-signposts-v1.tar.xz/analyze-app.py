import runpy
z=runpy.run_path('analyze.py'); parse=z['parse']; it=z['intervals']
grows,gg=parse('gpu-intervals.xml');arows,ag=parse('application.xml');import json; completed=json.load(open('completed-selected.json'))
for i in (11,9,21):
 d=it[78+i];a=d['start'];b=d['end'];print('TRIAL',i)
 for row in grows:
  c=list(row);s=int(gg(c[0]).text);dur=int(gg(c[1]).text)
  if s<b and s+dur>a:
   ident=gg(c[15]).text;print('gpu start/end',round((s-a)/1e6,6),round((s+dur-a)/1e6,6),'id',ident)
   for ar in arows:
    ac=list(ar)
    if ag(ac[11]).text==ident:
     at=int(ag(ac[0]).text);ad=int(ag(ac[1]).text);print('app',ag(ac[10]).get('fmt'),'start/end',round((at-a)/1e6,6),round((at+ad-a)/1e6,6))
   for cr in completed:
    if cr['id']==ident:
     ct=cr['timestamp_ns'];print('complete',round((ct-a)/1e6,6))
