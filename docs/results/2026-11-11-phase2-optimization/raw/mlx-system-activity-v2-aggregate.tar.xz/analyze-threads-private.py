import runpy,xml.etree.ElementTree as E,json,collections
z=runpy.run_path('analyze-private.py'); intervals=z['intervals'];idx=z['idx']; windows=[(i,intervals[78+i]['start'],intervals[78+i]['end']) for i in idx]; ids={};summary={i:collections.defaultdict(int) for i,_,_ in windows}
for event,e in E.iterparse('threads-all.xml',events=('end',)):
 if e.tag=='row':
  c=list(e)
  def get(x):return ids[x.get('ref')] if x.get('ref') else (x.text,x.get('fmt',''))
  p=get(c[4])[1];thread=get(c[1])[1]
  if p.startswith('mlx_block_segments (') and thread.startswith('Main Thread'):
   start=int(get(c[0])[0]);end=start+int(get(c[3])[0]);state=get(c[2])[1]
   for i,a,b in windows:
    duration=max(0,min(end,b)-max(start,a));summary[i][state]+=duration
  e.clear()
 elif e.get('id'):
  ids[e.get('id')]=(e.text,e.get('fmt',''))
for i,a,b in windows:
 print(json.dumps({'trial':i,'marker_ms':round((b-a)/1e6,6),'main_thread_states_ms':{k:round(v/1e6,6) for k,v in summary[i].items()},'covered_ms':round(sum(summary[i].values())/1e6,6)}))
