import json, re, statistics, xml.etree.ElementTree as ET
from pathlib import Path

def parse(path):
 root=ET.parse(path).getroot(); ids={e.get('id'):e for e in root.iter() if e.get('id')}; node=root.find('node')
 def get(e):
  while e.get('ref'): e=ids[e.get('ref')]
  return e
 return node.findall('row'),get

def overlap(items,a,b):
 spans=sorted((max(a,s),min(b,e)) for s,e in items if s<b and e>a)
 total=0;end=a
 for x,y in spans:
  total+=max(0,y-max(x,end));end=max(end,y)
 return round(total/1e6,6),len(spans)
rows,get=parse('markers-all.xml'); intervals={}
for row in rows:
 c=list(row)
 if not get(c[2]).get('fmt','').startswith('mlx_block_segments (') or get(c[6]).text!='ncm_block': continue
 meta=get(c[11]).get('fmt',''); m=re.fullmatch(r'batch=(\d+) sequence=(\d+)',meta)
 if not m: continue
 batch,seq=map(int,m.groups()); d=intervals.setdefault(seq,{'batch':batch}); key={'Begin':'start','Event':'graph','End':'end'}[get(c[3]).text];assert key not in d;d[key]=int(get(c[0]).text)
assert len(intervals)==108
r=json.load(open('report.json')); m=next(x for x in r['measurements'] if x['batch']==4 and x['scope']=='resident_decoder_block'); vals=m['trials_ms']; seg=m['block_graph_eval_ms']; assert len(vals)==len(seg)==30
for i in range(30):
 d=intervals[78+i];assert d['batch']==4 and abs((d['end']-d['start'])/1e6-vals[i])<.15
med=statistics.median(vals); idx=[i for i,v in enumerate(vals) if v>1.2*med];idx+=sorted(range(30),key=lambda i:abs(vals[i]-med))[:3]
rows,get=parse('gpu-all.xml'); gpu=[]
for row in rows:
 c=list(row);s=int(get(c[0]).text);dur=int(get(c[1]).text);proc=get(c[10]).get('fmt',''); ident=get(c[15]).text;gpu.append((s,s+dur,proc,ident,get(c[2]).get('fmt','')))
rows,get=parse('app-all.xml'); apps=[]
for row in rows:
 c=list(row);s=int(get(c[0]).text);dur=int(get(c[1]).text);apps.append((s,s+dur,get(c[2]).get('fmt',''),get(c[10]).get('fmt',''),get(c[11]).text))
print(json.dumps({'batch4_median_ms':med,'slow_count':len(idx)-3,'compared_indices':idx,'gpu_records':len(gpu),'app_records':len(apps)}))
for i in idx:
 d=intervals[78+i];a=d['start'];b=d['end']; tg=[x for x in gpu if x[2].startswith('mlx_block_segments (') and x[0]<b and x[1]>a]; other=[(x[0],x[1]) for x in gpu if not x[2].startswith('mlx_block_segments (')];
 print(json.dumps({'trial':i,'wall_ms':vals[i],'graph_ms':seg[i][0],'eval_ms':seg[i][1],'target_gpu':[[round((s-a)/1e6,6),round((e-a)/1e6,6),ident,ch] for s,e,_,ident,ch in tg],'other_gpu_union_during_marker_ms_and_records':overlap(other,a,b)}))
 for s,e,proc,ident,ch in tg:
  match=[x for x in apps if x[2].startswith('mlx_block_segments (') and x[4]==ident]
  print(json.dumps({'trial':i,'gpu_id':ident,'target_app':[[round((x[0]-a)/1e6,6),round((x[1]-a)/1e6,6),x[3]] for x in match], 'other_gpu_union_between_marker_and_gpu_start_ms_and_records':overlap(other,a,s)}))
