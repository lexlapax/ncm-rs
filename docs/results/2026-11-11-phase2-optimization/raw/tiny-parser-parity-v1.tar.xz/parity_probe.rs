use ncm_tokenizers::ByteBpe;
use serde_json::json;
use std::{env,fs,path::Path};
fn main() -> Result<(),Box<dyn std::error::Error>> {
    let dir=env::args().nth(1).ok_or("missing corpus")?;
    let mut files=fs::read_dir(dir)?.map(|e| e.map(|x|x.path())).collect::<std::io::Result<Vec<_>>>()?;
    files.sort();
    let mut results=Vec::new();
    for path in files {
        if !Path::new(&path).is_file() {continue}
        let data=fs::read(&path)?;
        let result=match ByteBpe::from_json(&data) {
            Ok(tok)=>{
                let mut rows=Vec::new();
                for text in ["", "a", "ababab", "a b\n", "é 猫", "<|pad|>ab<|endoftext|>"] {
                    let ids=tok.encode(text)?;
                    rows.push(json!({"text":text,"decode":tok.decode(&ids,false)?,"skip":tok.decode(&ids,true)?,"ids":ids}));
                }
                json!({"accepted":true,"vocab_size":tok.vocab_size(),"cases":rows,"invalid_id_rejected":tok.decode(&[u32::MAX],false).is_err()})
            },
            Err(e)=>json!({"accepted":false,"error_kind": match e { ncm_tokenizers::AssetError::Invalid(_)=>"invalid",ncm_tokenizers::AssetError::Json(_)=>"json",ncm_tokenizers::AssetError::Io(_)=>"io"}}),
        };
        results.push(json!({"file":path.file_name().unwrap().to_string_lossy(),"result":result}));
    }
    println!("{}",serde_json::to_string_pretty(&results)?); Ok(())
}
